// Layout Mapping Script
// Reads input.json and writes owners/layout_data.json and data/layout_data.json

const fs = require("fs");
const path = require("path");

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function readInput() {
  const inputPath = path.resolve("input.json");
  const raw = fs.readFileSync(inputPath, "utf-8");
  return JSON.parse(raw);
}

function getFolio(obj) {
  try {
    const arr = obj?.d?.parcelInfok__BackingField;
    if (Array.isArray(arr) && arr.length) {
      return arr[0]?.folioNumber || "unknown";
    }
  } catch {}
  return "unknown";
}

function defaultLayout(space_type, index) {
  return {
    space_type,
    space_index: index,
    flooring_material_type: null,
    size_square_feet: null,
    floor_level: null,
    has_windows: null,
    window_design_type: null,
    window_material_type: null,
    window_treatment_type: null,
    is_finished: false,
    furnished: null,
    paint_condition: null,
    flooring_wear: null,
    clutter_level: null,
    visible_damage: null,
    countertop_material: null,
    cabinet_style: null,
    fixture_finish_quality: null,
    design_style: null,
    natural_light_quality: null,
    decor_elements: null,
    pool_type: null,
    pool_equipment: null,
    spa_type: null,
    safety_features: null,
    view_type: null,
    lighting_features: null,
    condition_issues: null,
    is_exterior: false,
    pool_condition: null,
    pool_surface_type: null,
    pool_water_quality: null,
  };
}

function buildLayouts(input) {
  const parcel = input?.d?.parcelInfok__BackingField?.[0] || {};

  // Determine if parcel is land-only (no structures/rooms)
  const bldgSqFT = String(parcel?.bldgSqFT ?? "").trim();
  const units = String(parcel?.units ?? "").trim();
  const beds = String(parcel?.beds ?? "").trim();
  const baths = String(parcel?.baths ?? "").trim();
  const useCode = String(parcel?.useCode ?? "").toLowerCase();

  const landOnlyLikely =
    (bldgSqFT === "" || bldgSqFT === "0") &&
    (units === "" || units === "0") &&
    beds === "" &&
    baths === "" &&
    (useCode.includes("forest") ||
      useCode.includes("park") ||
      useCode.includes("recreational"));

  if (landOnlyLikely) {
    // For land-only parcels, do not fabricate rooms; return an empty layouts array
    return [];
  }

  // If structures existed, mapping logic would create per-room objects here.
  // With no room data available in this input, return an empty array by default.
  return [];
}

function main() {
  const data = readInput();
  const folio = getFolio(data);
  const key = `property_${folio}`;

  const layouts = buildLayouts(data);
  const outObj = { [key]: { layouts } };

  const ownersDir = path.resolve("owners");
  const dataDir = path.resolve("data");
  ensureDir(ownersDir);
  ensureDir(dataDir);

  fs.writeFileSync(
    path.join(ownersDir, "layout_data.json"),
    JSON.stringify(outObj, null, 2),
  );
  fs.writeFileSync(
    path.join(dataDir, "layout_data.json"),
    JSON.stringify(outObj, null, 2),
  );
}

if (require.main === module) {
  try {
    main();
    console.log("layoutMapping.js: Success");
  } catch (e) {
    console.error("layoutMapping.js: Failed", e);
    process.exit(1);
  }
}
