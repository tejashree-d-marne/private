const fs = require("fs");
const path = require("path");

function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function readJson(p) {
  const raw = fs.readFileSync(p, "utf-8");
  return JSON.parse(raw);
}

function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf-8");
}

function parseCurrency(val) {
  if (val === null || val === undefined) return null;
  if (typeof val === "number") return val > 0 ? Number(val.toFixed(2)) : null;
  if (typeof val === "string") {
    const clean = val.replace(/[$,\s]/g, "");
    if (clean === "") return null;
    const num = Number(clean);
    if (isNaN(num) || num <= 0) return null;
    return Math.round(num * 100) / 100;
  }
  return null;
}

function parseCurrencyAllowZero(val) {
  if (val === null || val === undefined) return null;
  if (typeof val === "number")
    return Number((Math.round(val * 100) / 100).toFixed(2));
  if (typeof val === "string") {
    const clean = val.replace(/[$,\s]/g, "");
    if (clean === "") return null;
    const num = Number(clean);
    if (isNaN(num)) return null;
    return Math.round(num * 100) / 100;
  }
  return null;
}

function titleCaseCounty(s) {
  if (!s) return null;
  const map = {
    "miami dade": "Miami Dade",
    "fort bend": "Fort Bend",
  };
  const lower = String(s).toLowerCase();
  if (map[lower]) return map[lower];
  return lower.replace(/\b\w/g, (ch) => ch.toUpperCase());
}

function main() {
  const dataDir = path.join(".", "data");
  ensureDir(dataDir);

  // Inputs
  const input = readJson(path.join(".", "input.json"));
  const addrInput = readJson(path.join(".", "unnormalized_address.json"));
  // property_seed.json is not directly needed for extraction but read to conform to requirements
  const seed = readJson(path.join(".", "property_seed.json"));

  // Owners/utilities/layout inputs from owners/*
  const ownersPath = path.join(".", "owners", "owner_data.json");
  const utilitiesPath = path.join(".", "owners", "utilities_data.json");
  const layoutPath = path.join(".", "owners", "layout_data.json");

  const ownersData = fs.existsSync(ownersPath) ? readJson(ownersPath) : null;
  const utilitiesData = fs.existsSync(utilitiesPath)
    ? readJson(utilitiesPath)
    : null;
  const layoutData = fs.existsSync(layoutPath) ? readJson(layoutPath) : null;

  const d = input && input.d ? input.d : {};
  const parcelInfo =
    Array.isArray(d.parcelInfok__BackingField) &&
    d.parcelInfok__BackingField.length > 0
      ? d.parcelInfok__BackingField[0]
      : {};
  const millage =
    Array.isArray(d.millageRatek__BackingField) &&
    d.millageRatek__BackingField.length > 0
      ? d.millageRatek__BackingField[0]
      : {};

  const parcelId =
    parcelInfo.folioNumber || seed.parcel_id || seed.request_identifier || null;

  // PROPERTY
  if (parcelId) {
    const bldgSqFtStr = parcelInfo.bldgSqFT;
    const bldgSqFt = bldgSqFtStr
      ? Number((String(bldgSqFtStr) || "0").replace(/[,\s]/g, ""))
      : 0;

    const property = {
      area_under_air: null,
      livable_floor_area: null,
      number_of_units_type: null,
      parcel_identifier: String(parcelId),
      property_legal_description_text: parcelInfo.legal || null,
      property_structure_built_year: null,
      property_type: bldgSqFt && bldgSqFt > 0 ? "SingleFamily" : "VacantLand",
      total_area: null,
      zoning: parcelInfo.useCodeName || parcelInfo.useCode || undefined,
    };
    writeJson(path.join(dataDir, "property.json"), property);
  }

  // ADDRESS
  {
    // Derive state from unnormalized full_address
    let state_code = null;
    if (addrInput && typeof addrInput.full_address === "string") {
      const parts = addrInput.full_address.split(",").map((s) => s.trim());
      if (parts.length > 0) {
        const last = parts[parts.length - 1];
        if (/^[A-Z]{2}$/i.test(last)) state_code = last.toUpperCase();
      }
    }

    const county = titleCaseCounty(addrInput && addrInput.county_jurisdiction);

    const address = {
      block: null,
      city_name: parcelInfo.situsCity || null,
      country_code: null,
      county_name: county || null,
      latitude: null,
      longitude: null,
      plus_four_postal_code: null,
      postal_code:
        parcelInfo.situsZipCode && parcelInfo.situsZipCode !== "0"
          ? parcelInfo.situsZipCode
          : null,
      range: null,
      route_number: null,
      section: null,
      state_code: state_code || null,
      street_name:
        parcelInfo.situsAddress1 || parcelInfo.situsStreetName || null,
      street_number: parcelInfo.situsStreetNumber || null,
      street_post_directional_text: parcelInfo.situsStreetDirection || null,
      street_pre_directional_text: null,
      street_suffix_type: parcelInfo.situsStreetType || null,
      township: null,
      unit_identifier: null,
    };

    writeJson(path.join(dataDir, "address.json"), address);
  }

  // LOT (all nulls where not available)
  {
    const lot = {
      lot_type: null,
      lot_length_feet: null,
      lot_width_feet: null,
      lot_area_sqft: null,
      landscaping_features: null,
      view: null,
      fencing_type: null,
      fence_height: null,
      fence_length: null,
      driveway_material: null,
      driveway_condition: null,
      lot_condition_issues: null,
    };
    writeJson(path.join(dataDir, "lot.json"), lot);
  }

  // TAX
  {
    const assessed =
      parseCurrency(parcelInfo.sohValue) ||
      parseCurrency(parcelInfo.assessedLastYearValue) ||
      parseCurrency(parcelInfo.assessedLastTwoYearsValue);
    const market =
      parseCurrency(parcelInfo.justValue) ||
      parseCurrency(parcelInfo.justLastYearValue) ||
      parseCurrency(parcelInfo.justLastTwoYearsValue);
    const building = parseCurrencyAllowZero(parcelInfo.bldgValue); // allow 0
    const land = parseCurrencyAllowZero(parcelInfo.landValue);

    // Determine taxable value: prefer explicit taxableAmount* fields; choose the maximum among them
    const taxableCandidatesRaw = [
      parcelInfo.taxableAmountCounty,
      parcelInfo.taxableAmountIndependent,
      parcelInfo.taxableAmountMunicipal,
      parcelInfo.taxableAmountSchoolBoard,
    ];
    const taxableCandidates = taxableCandidatesRaw
      .map((v) => parseCurrencyAllowZero(v))
      .filter((v) => v !== null);

    let taxable = null;
    if (taxableCandidates.length > 0) {
      taxable = Math.max(...taxableCandidates);
    } else {
      // fallback to SOH values if explicit taxable amounts not present
      taxable =
        parseCurrencyAllowZero(parcelInfo.sohSbValue) ??
        parseCurrencyAllowZero(parcelInfo.sohValue);
    }

    if (assessed && market && taxable !== null) {
      const tax = {
        monthly_tax_amount: null,
        period_end_date: null,
        period_start_date: null,
        property_assessed_value_amount: assessed,
        property_building_amount: building,
        property_land_amount: land,
        property_market_value_amount: market,
        property_taxable_value_amount: taxable,
        tax_year:
          millage && millage.millageYear
            ? parseInt(millage.millageYear, 10)
            : null,
      };
      writeJson(path.join(dataDir, "tax_1.json"), tax);
    }
  }

  // FLOOD: No data in input.json; do not create file when absent

  // SALES: No sales info; do not create files

  // STRUCTURE: From input.json (nulls if absent)
  {
    const structure = {
      architectural_style_type: null,
      attachment_type: null,
      exterior_wall_material_primary: null,
      exterior_wall_material_secondary: null,
      exterior_wall_condition: null,
      exterior_wall_insulation_type: null,
      flooring_material_primary: null,
      flooring_material_secondary: null,
      subfloor_material: null,
      flooring_condition: null,
      interior_wall_structure_material: null,
      interior_wall_surface_material_primary: null,
      interior_wall_surface_material_secondary: null,
      interior_wall_finish_primary: null,
      interior_wall_finish_secondary: null,
      interior_wall_condition: null,
      roof_covering_material: null,
      roof_underlayment_type: null,
      roof_structure_material: null,
      roof_design_type: null,
      roof_condition: null,
      roof_age_years: null,
      gutters_material: null,
      gutters_condition: null,
      roof_material_type: null,
      foundation_type: null,
      foundation_material: null,
      foundation_waterproofing: null,
      foundation_condition: null,
      ceiling_structure_material: null,
      ceiling_surface_material: null,
      ceiling_insulation_type: null,
      ceiling_height_average: null,
      ceiling_condition: null,
      exterior_door_material: null,
      interior_door_material: null,
      window_frame_material: null,
      window_glazing_type: null,
      window_operation_type: null,
      window_screen_material: null,
      primary_framing_material: null,
      secondary_framing_material: null,
      structural_damage_indicators: null,
      finished_base_area: null,
      finished_basement_area: null,
      finished_upper_story_area: null,
      unfinished_base_area: null,
      unfinished_basement_area: null,
      unfinished_upper_story_area: null,
      exterior_wall_condition_primary: null,
      exterior_wall_condition_secondary: null,
      exterior_wall_insulation_type_primary: null,
      exterior_wall_insulation_type_secondary: null,
      interior_wall_structure_material_primary: null,
      interior_wall_structure_material_secondary: null,
    };
    writeJson(path.join(dataDir, "structure.json"), structure);
  }

  // UTILITIES: from owners/utilities_data.json
  if (utilitiesData && parcelId) {
    const key = `property_${parcelId}`;
    const u = utilitiesData[key];
    if (u) {
      const utility = {
        cooling_system_type: u.cooling_system_type ?? null,
        heating_system_type: u.heating_system_type ?? null,
        public_utility_type: u.public_utility_type ?? null,
        sewer_type: u.sewer_type ?? null,
        water_source_type: u.water_source_type ?? null,
        plumbing_system_type: u.plumbing_system_type ?? null,
        plumbing_system_type_other_description:
          u.plumbing_system_type_other_description ?? null,
        electrical_panel_capacity: u.electrical_panel_capacity ?? null,
        electrical_wiring_type: u.electrical_wiring_type ?? null,
        hvac_condensing_unit_present: u.hvac_condensing_unit_present ?? null,
        electrical_wiring_type_other_description:
          u.electrical_wiring_type_other_description ?? null,
        solar_panel_present: u.solar_panel_present === true,
        solar_panel_type: u.solar_panel_type ?? null,
        solar_panel_type_other_description:
          u.solar_panel_type_other_description ?? null,
        smart_home_features: u.smart_home_features ?? null,
        smart_home_features_other_description:
          u.smart_home_features_other_description ?? null,
        hvac_unit_condition: u.hvac_unit_condition ?? null,
        solar_inverter_visible: u.solar_inverter_visible === true,
        hvac_unit_issues: u.hvac_unit_issues ?? null,
      };
      writeJson(path.join(dataDir, "utility.json"), utility);
    }
  }

  // LAYOUTS: from owners/layout_data.json (if any)
  if (layoutData && parcelId) {
    const key = `property_${parcelId}`;
    const ld = layoutData[key];
    if (ld && Array.isArray(ld.layouts) && ld.layouts.length > 0) {
      ld.layouts.forEach((layout, idx) => {
        // Write exactly as provided, assuming producer adhered to schema
        writeJson(path.join(dataDir, `layout_${idx + 1}.json`), layout);
      });
    }
  }

  // OWNERS: from owners/owner_data.json
  if (ownersData && parcelId) {
    const key = `property_${parcelId}`;
    const od = ownersData[key];
    if (od && od.owners_by_date && Array.isArray(od.owners_by_date.current)) {
      const owners = od.owners_by_date.current;
      // Determine if all are same type (person/company). We will only support a single type per property.
      const hasCompany = owners.some((o) => o.type === "company");
      const hasPerson = owners.some((o) => o.type === "person");
      if (hasCompany && !hasPerson) {
        owners.forEach((o, i) => {
          const company = { name: o.name || null };
          writeJson(path.join(dataDir, `company_${i + 1}.json`), company);
        });
      } else if (hasPerson && !hasCompany) {
        owners.forEach((o, i) => {
          // Person schema requires many fields; if missing, set nulls per schema.
          const person = {
            birth_date: o.birth_date || null,
            first_name: o.first_name || null,
            last_name: o.last_name || null,
            middle_name: o.middle_name || null,
            prefix_name: o.prefix_name || null,
            suffix_name: o.suffix_name || null,
            us_citizenship_status: o.us_citizenship_status || null,
            veteran_status:
              typeof o.veteran_status === "boolean" ? o.veteran_status : null,
          };
          writeJson(path.join(dataDir, `person_${i + 1}.json`), person);
        });
      }
      // Relationship files require sales files; since we didn't create sales, we skip relationships.
    }
  }
}

main();
