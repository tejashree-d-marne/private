// Transform a single property's HTML/JSON into structured owners JSON using cheerio for HTML parsing if needed.
// Requirements adhered: single file, only cheerio for HTML parsing, JSON processing in vanilla JS, no logging/validation beyond output.

const fs = require("fs");
const path = require("path");
const cheerio = require("cheerio");

// Utility: compact whitespace and trim
function normalizeSpace(str) {
  return String(str || "")
    .replace(/[\u00A0\s]+/g, " ")
    .replace(/[\t\n\r]+/g, " ")
    .trim();
}

// Utility: deep traversal to find nodes
function traverse(node, visit, pathArr = []) {
  if (node && typeof node === "object") {
    visit(node, pathArr);
    if (Array.isArray(node)) {
      for (let i = 0; i < node.length; i++) {
        traverse(node[i], visit, pathArr.concat([`[${i}]`]));
      }
    } else {
      for (const key of Object.keys(node)) {
        traverse(node[key], visit, pathArr.concat([key]));
      }
    }
  }
}

// Try to parse a date string into YYYY-MM-DD; return null if not reliable
function parseDateToYMD(raw) {
  if (!raw) return null;
  let s = normalizeSpace(raw);
  if (!s) return null;
  // Common formats: YYYY-MM-DD
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) {
    const y = m[1];
    const mo = String(m[2]).padStart(2, "0");
    const d = String(m[3]).padStart(2, "0");
    return `${y}-${mo}-${d}`;
  }
  // MM/DD/YYYY or M/D/YYYY
  m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    const mo = String(m[1]).padStart(2, "0");
    const d = String(m[2]).padStart(2, "0");
    const y = m[3];
    return `${y}-${mo}-${d}`;
  }
  // Month D, YYYY
  m = s.match(
    /^(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s*(\d{4})$/i,
  );
  if (m) {
    const months = {
      january: "01",
      february: "02",
      march: "03",
      april: "04",
      may: "05",
      june: "06",
      july: "07",
      august: "08",
      september: "09",
      october: "10",
      november: "11",
      december: "12",
    };
    const mo = months[m[1].toLowerCase()];
    const d = String(m[2]).padStart(2, "0");
    const y = m[3];
    return `${y}-${mo}-${d}`;
  }
  // YYYY only is not precise enough per requirements
  return null;
}

// Normalize owner raw string for deduplication
function normalizeOwnerKey(raw) {
  return normalizeSpace(raw).toLowerCase();
}

// Company detection keywords (case-insensitive)
const COMPANY_KEYWORDS = [
  "inc",
  "llc",
  "l.l.c",
  "ltd",
  "foundation",
  "alliance",
  "solutions",
  "corp",
  "corporation",
  "co",
  "company",
  "services",
  "trust",
  "tr",
  "bank",
  "associates",
  "association",
  "ministries",
  "church",
  "partners",
  "group",
  "holdings",
  "plc",
  "lp",
  "llp",
  "pc",
  "p.c",
  "management",
  "district",
  "authority",
  "city",
  "county",
  "board",
  "department",
  "university",
  "college",
  "academy",
  "hoa",
  "homeowners",
  "assn",
  "club",
];
const COMPANY_REGEX = new RegExp(
  `\\b(${COMPANY_KEYWORDS.map((k) => k.replace(/[-/\\.^$*+?()[\\]{}|]/g, (r) => r)).join("|")})\\b`,
  "i",
);

function isLikelyCompany(name) {
  const n = normalizeSpace(name);
  if (!n) return false;
  if (COMPANY_REGEX.test(n)) return true;
  // Heuristic: many words and mostly uppercase suggests org
  const words = n.split(/\s+/);
  if (words.length >= 3) {
    const upperish = words.filter(
      (w) => /[A-Z]/.test(w) && w === w.toUpperCase(),
    );
    if (upperish.length >= Math.ceil(words.length * 0.7)) return true;
  }
  return false;
}

function classifyOwner(raw) {
  const original = normalizeSpace(raw);
  if (!original) return null;
  const name = original.replace(/\s{2,}/g, " ").trim();

  if (isLikelyCompany(name)) {
    return { type: "company", name };
  }

  // If contains '&' or ' and ', remove and split into name parts per instruction
  if (/[&]/.test(name) || /\band\b/i.test(name)) {
    const tokens = name
      .replace(/&/g, " ")
      .replace(/\band\b/gi, " ")
      .split(/\s+/)
      .filter(Boolean);
    if (tokens.length >= 2) {
      const first_name = tokens[0];
      const last_name = tokens[tokens.length - 1];
      const middle = tokens.slice(1, -1).join(" ");
      const out = { type: "person", first_name, last_name };
      if (middle) out.middle_name = middle;
      return out;
    } else {
      return null;
    }
  }

  // Person fallback: handle "LAST, FIRST M" or "First M Last"
  let s = name;
  if (/,/.test(s)) {
    const parts = s.split(",").map((x) => normalizeSpace(x));
    if (parts.length >= 2) {
      const last = parts[0];
      const rest = parts.slice(1).join(" ");
      s = `${rest} ${last}`;
    }
  }
  const tokens = s.split(/\s+/).filter(Boolean);
  if (tokens.length < 2) return null;
  const first_name = tokens[0];
  const last_name = tokens[tokens.length - 1];
  const middle = tokens.slice(1, -1).join(" ");
  const out = { type: "person", first_name, last_name };
  if (middle) out.middle_name = middle;
  return out;
}

// Extract owners from an object node: returns array of raw strings
function extractOwnersFromObject(obj) {
  const owners = [];
  const keys = Object.keys(obj || {});
  // Group numeric-suffixed owner fields by base key
  const groups = {};
  const noise = [
    "alert",
    "verify",
    "verified",
    "ship",
    "ownership",
    "type",
    "percent",
    "pct",
    "address",
    "addr",
    "mail",
    "mailing",
    "status",
    "code",
    "city",
    "zip",
    "state",
    "phone",
    "email",
    "id",
    "number",
    "num",
    "count",
    "cnt",
    "year",
    "exemption",
  ];
  for (const k of keys) {
    const v = obj[k];
    if (typeof v === "string" || typeof v === "number") {
      const keyLower = k.toLowerCase();
      if (keyLower.includes("owner")) {
        // Skip known non-name owner-related keys
        if (noise.some((nz) => keyLower.includes(nz))) continue;
        const val = normalizeSpace(String(v));
        if (!val) continue;
        const m = k.match(/^(.*?)(\d+)$/); // ownerName1, ownerName2, owner1, etc.
        if (m && m[1].toLowerCase().includes("owner")) {
          const base = m[1].toLowerCase();
          if (!groups[base]) groups[base] = [];
          groups[base].push(val);
        } else {
          owners.push(val);
        }
      }
    }
  }
  // Join grouped parts
  for (const base of Object.keys(groups)) {
    const vals = groups[base].filter(Boolean);
    if (vals.length) {
      owners.push(vals.join(" "));
    }
  }
  return owners;
}

// Extract a likely date from the same object
function extractDateFromObject(obj) {
  for (const [k, v] of Object.entries(obj || {})) {
    if (typeof v !== "string" && typeof v !== "number") continue;
    const keyLower = k.toLowerCase();
    if (
      keyLower.includes("date") ||
      keyLower.includes("record") ||
      keyLower.includes("effective")
    ) {
      const d = parseDateToYMD(String(v));
      if (d) return d;
    }
  }
  return null;
}

// Attempt to find a property ID across the structure
function findPropertyId(root) {
  const idKeys = [
    "property_id",
    "propertyid",
    "propid",
    "prop_id",
    "folio",
    "folionumber",
    "folio_number",
    "parcel",
    "parcelid",
    "parcel_id",
    "strap",
    "apn",
    "apnnumber",
    "account",
    "accountnumber",
  ];
  let found = null;
  traverse(root, (node) => {
    if (found) return;
    if (node && typeof node === "object" && !Array.isArray(node)) {
      for (const [k, v] of Object.entries(node)) {
        if (typeof v !== "string" && typeof v !== "number") continue;
        const keyLower = k.toLowerCase();
        if (idKeys.includes(keyLower)) {
          const val = normalizeSpace(String(v));
          if (val) {
            found = val;
            return;
          }
        }
      }
    }
  });
  return found || "unknown_id";
}

// Main execution: read input, build output JSON
(function main() {
  const inputPath = path.join(process.cwd(), "input.json");
  const raw = fs.readFileSync(inputPath, "utf8");
  const text = raw.trim();

  let data = null;
  // Primary path: JSON input
  data = JSON.parse(text);

  // If input was HTML, you could parse as:
  // const $ = cheerio.load(text); // Not used here since provided sample is JSON

  // Aggregate owner groups with potential dates
  const groups = []; // { ownersRaw: string[], date: string|null, nodeRef: object }
  let primaryObj = null;
  let propertyId = findPropertyId(data);

  traverse(data, (node) => {
    if (!node || typeof node !== "object" || Array.isArray(node)) return;
    const ownersHere = extractOwnersFromObject(node);
    if (ownersHere.length) {
      const date = extractDateFromObject(node);
      groups.push({ ownersRaw: ownersHere, date, nodeRef: node });
      // Heuristic: Node that contains the discovered propertyId is primary
      if (!primaryObj) {
        for (const [k, v] of Object.entries(node)) {
          if (typeof v !== "string" && typeof v !== "number") continue;
          const keyLower = k.toLowerCase();
          const val = normalizeSpace(String(v));
          if (val && propertyId !== "unknown_id") {
            const idLower = propertyId.toLowerCase();
            if (
              keyLower.includes("folio") ||
              keyLower.includes("parcel") ||
              keyLower.includes("property") ||
              keyLower.includes("prop")
            ) {
              if (val.toLowerCase() === idLower) {
                primaryObj = node;
              }
            }
          }
        }
      }
    }
  });

  // Determine current owners: owners from primaryObj if available; else all owners without dates
  let currentOwnersRaw = [];
  if (primaryObj) {
    currentOwnersRaw = extractOwnersFromObject(primaryObj);
  } else {
    for (const g of groups) if (!g.date) currentOwnersRaw.push(...g.ownersRaw);
  }

  // Build owners_by_date map
  const ownersByDate = {};
  const invalidOwners = [];

  // Helper to add owners to a bucket (date key)
  function addOwnersToKey(key, rawList) {
    if (!ownersByDate[key]) ownersByDate[key] = [];
    const seen = new Set(
      ownersByDate[key].map((o) =>
        o.type === "company"
          ? normalizeOwnerKey(o.name)
          : normalizeOwnerKey(
              [o.first_name, o.middle_name || "", o.last_name].join(" "),
            ),
      ),
    );
    for (const raw of rawList) {
      const cleaned = normalizeSpace(raw);
      if (!cleaned) continue;
      const classified = classifyOwner(cleaned);
      if (!classified) {
        const reason = "Unclassifiable or insufficient data";
        const k = normalizeOwnerKey(cleaned);
        if (!invalidOwners.find((io) => normalizeOwnerKey(io.raw) === k))
          invalidOwners.push({ raw: cleaned, reason });
        continue;
      }
      let keyForDupe = "";
      if (classified.type === "company")
        keyForDupe = normalizeOwnerKey(classified.name);
      else
        keyForDupe = normalizeOwnerKey(
          [
            classified.first_name,
            classified.middle_name || "",
            classified.last_name,
          ].join(" "),
        );
      if (seen.has(keyForDupe)) continue;
      ownersByDate[key].push(classified);
      seen.add(keyForDupe);
    }
  }

  // First, process groups that have dates
  const datedGroups = groups.filter((g) => !!g.date);
  // Unique dates in chronological order
  const uniqueDates = Array.from(new Set(datedGroups.map((g) => g.date)))
    .filter(Boolean)
    .sort();
  for (const d of uniqueDates) {
    const allOwners = [];
    for (const g of datedGroups)
      if (g.date === d) allOwners.push(...g.ownersRaw);
    addOwnersToKey(d, allOwners);
  }

  // Then groups without dates: assign unknown_date_1, unknown_date_2, ...
  const undatedGroups = groups.filter((g) => !g.date);
  let unknownIdx = 1;
  for (const g of undatedGroups) {
    // If this is the primary object, skip assigning to unknown and let it be 'current'
    if (primaryObj && g.nodeRef === primaryObj) continue;
    const key = `unknown_date_${unknownIdx++}`;
    addOwnersToKey(key, g.ownersRaw);
  }

  // Finally add 'current' from primary owners
  addOwnersToKey("current", currentOwnersRaw);

  // Build ordered owners_by_date: all valid dates asc, then unknown_date_*, then current
  const ordered = {};
  const dateKeys = Object.keys(ownersByDate)
    .filter((k) => /^\d{4}-\d{2}-\d{2}$/.test(k))
    .sort();
  for (const k of dateKeys) ordered[k] = ownersByDate[k];
  const unknownKeys = Object.keys(ownersByDate)
    .filter((k) => k.startsWith("unknown_date_"))
    .sort((a, b) => {
      const na = parseInt(a.replace(/\D/g, ""), 10) || 0;
      const nb = parseInt(b.replace(/\D/g, ""), 10) || 0;
      return na - nb;
    });
  for (const k of unknownKeys) ordered[k] = ownersByDate[k];
  ordered["current"] = ownersByDate["current"] || [];

  const idSafe = propertyId || "unknown_id";
  const output = {
    [`property_${idSafe}`]: {
      owners_by_date: ordered,
    },
    invalid_owners: invalidOwners,
  };

  // Ensure output directory
  const outDir = path.join(process.cwd(), "owners");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, "owner_data.json");
  const serialized = JSON.stringify(output, null, 2);
  fs.writeFileSync(outPath, serialized, "utf8");
  console.log(serialized);
})();
