// Utility Mapping Script
// Reads input.json and writes owners/utilities_data.json and data/utilities_data.json

const fs = require("fs");
const path = require("path");

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function readInput() {
  const inputPath = path.resolve("input.json");
  const raw = fs.readFileSync(inputPath, "utf-8");
  return JSON.parse(raw);
}

function getFolio(obj) {
  try {
    const arr = obj?.d?.parcelInfok__BackingField;
    if (Array.isArray(arr) && arr.length) {
      return arr[0]?.folioNumber || "unknown";
    }
  } catch {}
  return "unknown";
}

function buildUtilities() {
  return {
    cooling_system_type: null,
    heating_system_type: null,
    public_utility_type: null,
    sewer_type: null,
    water_source_type: null,
    plumbing_system_type: null,
    plumbing_system_type_other_description: null,
    electrical_panel_capacity: null,
    electrical_wiring_type: null,
    hvac_condensing_unit_present: null,
    electrical_wiring_type_other_description: null,
    solar_panel_present: false,
    solar_panel_type: null,
    solar_panel_type_other_description: null,
    smart_home_features: null,
    smart_home_features_other_description: null,
    hvac_unit_condition: null,
    solar_inverter_visible: false,
    hvac_unit_issues: null,
  };
}

function main() {
  const data = readInput();
  const folio = getFolio(data);
  const key = `property_${folio}`;

  const utilities = buildUtilities();
  const outObj = { [key]: utilities };

  const ownersDir = path.resolve("owners");
  const dataDir = path.resolve("data");
  ensureDir(ownersDir);
  ensureDir(dataDir);

  fs.writeFileSync(
    path.join(ownersDir, "utilities_data.json"),
    JSON.stringify(outObj, null, 2),
  );
  fs.writeFileSync(
    path.join(dataDir, "utilities_data.json"),
    JSON.stringify(outObj, null, 2),
  );
}

if (require.main === module) {
  try {
    main();
    console.log("utilityMapping.js: Success");
  } catch (e) {
    console.error("utilityMapping.js: Failed", e);
    process.exit(1);
  }
}
