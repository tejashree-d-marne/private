// Structure Mapping Script
// Reads input.json and writes owners/structure_data.json and data/structure_data.json

const fs = require("fs");
const path = require("path");

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function readInput() {
  const inputPath = path.resolve("input.json");
  const raw = fs.readFileSync(inputPath, "utf-8");
  return JSON.parse(raw);
}

function getFolio(obj) {
  try {
    const arr = obj?.d?.parcelInfok__BackingField;
    if (Array.isArray(arr) && arr.length) {
      return arr[0]?.folioNumber || "unknown";
    }
  } catch {}
  return "unknown";
}

function buildStructure() {
  // All required fields per schema, default to null unless type demands otherwise
  return {
    architectural_style_type: null,
    attachment_type: null,
    exterior_wall_material_primary: null,
    exterior_wall_material_secondary: null,
    exterior_wall_condition: null,
    exterior_wall_insulation_type: null,
    flooring_material_primary: null,
    flooring_material_secondary: null,
    subfloor_material: null,
    flooring_condition: null,
    interior_wall_structure_material: null,
    interior_wall_surface_material_primary: null,
    interior_wall_surface_material_secondary: null,
    interior_wall_finish_primary: null,
    interior_wall_finish_secondary: null,
    interior_wall_condition: null,
    roof_covering_material: null,
    roof_underlayment_type: null,
    roof_structure_material: null,
    roof_design_type: null,
    roof_condition: null,
    roof_age_years: null,
    gutters_material: null,
    gutters_condition: null,
    roof_material_type: null,
    foundation_type: null,
    foundation_material: null,
    foundation_waterproofing: null,
    foundation_condition: null,
    ceiling_structure_material: null,
    ceiling_surface_material: null,
    ceiling_insulation_type: null,
    ceiling_height_average: null,
    ceiling_condition: null,
    exterior_door_material: null,
    interior_door_material: null,
    window_frame_material: null,
    window_glazing_type: null,
    window_operation_type: null,
    window_screen_material: null,
    primary_framing_material: null,
    secondary_framing_material: null,
    structural_damage_indicators: null,
    // Optional numeric area fields (not required) could be added if needed using nulls
    finished_base_area: null,
    finished_basement_area: null,
    finished_upper_story_area: null,
    unfinished_base_area: null,
    unfinished_basement_area: null,
    unfinished_upper_story_area: null,
    exterior_wall_condition_primary: null,
    exterior_wall_condition_secondary: null,
    exterior_wall_insulation_type_primary: null,
    exterior_wall_insulation_type_secondary: null,
    interior_wall_structure_material_primary: null,
    interior_wall_structure_material_secondary: null,
  };
}

function main() {
  const data = readInput();
  const folio = getFolio(data);
  const key = `property_${folio}`;

  const structure = buildStructure();
  const outObj = { [key]: structure };

  const ownersDir = path.resolve("owners");
  const dataDir = path.resolve("data");
  ensureDir(ownersDir);
  ensureDir(dataDir);

  fs.writeFileSync(
    path.join(ownersDir, "structure_data.json"),
    JSON.stringify(outObj, null, 2),
  );
  fs.writeFileSync(
    path.join(dataDir, "structure_data.json"),
    JSON.stringify(outObj, null, 2),
  );
}

if (require.main === module) {
  try {
    main();
    console.log("structureMapping.js: Success");
  } catch (e) {
    console.error("structureMapping.js: Failed", e);
    process.exit(1);
  }
}
