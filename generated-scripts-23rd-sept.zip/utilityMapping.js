// Utility mapping script
// Reads input.json and writes owners/utilities_data.json keyed by property_[folio]

const fs = require("fs");
const path = require("path");
const cheerio = require("cheerio");

function safeParseJSON(str) {
  try {
    return JSON.parse(str);
  } catch (e) {
    return null;
  }
}

function extractFromInput(inputObj) {
  const root = inputObj.d || inputObj;
  const parcelArr = root.parcelInfok__BackingField || [];
  const parcel = parcelArr[0] || {};
  const folio = parcel.folioNumber || parcel.folio || "unknown";

  // With limited data, default many utility fields to null or sensible defaults per schema
  const utility = {
    cooling_system_type: null,
    heating_system_type: null,
    public_utility_type: null,
    sewer_type: null,
    water_source_type: null,
    plumbing_system_type: null,
    plumbing_system_type_other_description: null,
    electrical_panel_capacity: null,
    electrical_wiring_type: null,
    hvac_condensing_unit_present: null,
    electrical_wiring_type_other_description: null,
    solar_panel_present: false,
    solar_panel_type: null,
    solar_panel_type_other_description: null,
    smart_home_features: null,
    smart_home_features_other_description: null,
    hvac_unit_condition: null,
    solar_inverter_visible: false,
    hvac_unit_issues: null,
  };

  return { folio, utility };
}

(function main() {
  const inputPath = path.resolve("input.json");
  const raw = fs.readFileSync(inputPath, "utf8");
  let parsed = safeParseJSON(raw);
  if (!parsed) {
    const $ = cheerio.load(raw || "");
    const text = $("body").text().trim();
    parsed = safeParseJSON(text);
  }
  if (!parsed) throw new Error("Unable to parse input.json");

  const { folio, utility } = extractFromInput(parsed);

  const outObj = {};
  outObj[`property_${folio}`] = utility;

  const outDir = path.resolve("owners");
  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, "utilities_data.json");
  fs.writeFileSync(outPath, JSON.stringify(outObj, null, 2), "utf8");
})();
