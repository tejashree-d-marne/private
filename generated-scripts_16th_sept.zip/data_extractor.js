const fs = require("fs");
const path = require("path");

function readJSON(p) {
  const full = path.resolve(p);
  const raw = fs.readFileSync(full, "utf8");
  return JSON.parse(raw);
}

function ensureDir(p) {
  const full = path.resolve(p);
  if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
}

function writeJSON(relPath, obj) {
  const full = path.resolve(relPath);
  fs.writeFileSync(full, JSON.stringify(obj, null, 2), "utf8");
}

function parseCurrencyToNumber(val) {
  if (val == null) return null;
  if (typeof val === "number") return val;
  if (typeof val !== "string") return null;
  const cleaned = val.replace(/[^0-9.\-]/g, "");
  if (cleaned === "") return null;
  const num = Number(cleaned);
  if (!isFinite(num)) return null;
  return Math.round(num * 100) / 100;
}

function parseIntSafe(s) {
  if (s == null) return null;
  const n = parseInt(String(s).trim(), 10);
  return isNaN(n) ? null : n;
}

function normalizeDate(val) {
  if (!val) return null;
  const s = String(val).trim();
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const us = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (us) {
    const mm = us[1].padStart(2, "0");
    const dd = us[2].padStart(2, "0");
    const yyyy = us[3];
    return `${yyyy}-${mm}-${dd}`;
  }
  return s;
}

function extractAddress(
  fullAddress,
  situsCity,
  situsZipCode,
  countyJurisdiction,
) {
  let street_number = null;
  let street_pre_directional_text = null;
  let street_name = null;
  let street_suffix_type = null;
  let city_name = null;
  let state_code = null;
  let postal_code = null;
  let plus_four_postal_code = null;

  if (typeof fullAddress === "string") {
    const parts = fullAddress.split(",");
    const line1 = (parts[0] || "").trim();
    const line2 = (parts[1] || "").trim();
    const line3 = (parts[2] || "").trim();

    const tokens = line1.split(/\s+/).filter(Boolean);
    if (tokens.length >= 3) {
      street_number = tokens[0] || null;
      if (["N", "S", "E", "W", "NE", "NW", "SE", "SW"].includes(tokens[1])) {
        street_pre_directional_text = tokens[1];
      }
      const remain = tokens.slice(2);
      if (remain.length >= 1) street_name = remain[0];
      if (remain.length >= 2) {
        let suf = remain[1].toUpperCase();
        const map = {
          ST: "St",
          STREET: "St",
          AVE: "Ave",
          AVENUE: "Ave",
          RD: "Rd",
          ROAD: "Rd",
          CT: "Ct",
          COURT: "Ct",
          BLVD: "Blvd",
          BOULEVARD: "Blvd",
          LN: "Ln",
          LANE: "Ln",
          DR: "Dr",
          DRIVE: "Dr",
          TER: "Ter",
          TERRACE: "Ter",
          CIR: "Cir",
          CIRCLE: "Cir",
          PL: "Pl",
          PLACE: "Pl",
          WAY: "Way",
          HWY: "Hwy",
          HIGHWAY: "Hwy",
          PKWY: "Pkwy",
          PARKWAY: "Pkwy",
        };
        street_suffix_type =
          map[suf] || suf.charAt(0) + suf.slice(1).toLowerCase();
      }
    }

    if (line2) city_name = line2.toUpperCase();
    if (line3) {
      const m = line3.match(/([A-Z]{2})\s+(\d{5})(?:-(\d{4}))?/);
      if (m) {
        state_code = m[1];
        postal_code = m[2];
        plus_four_postal_code = m[3] || null;
      }
    }
  }

  // Prefer situsCity; enrich postal code and plus-four using situsZipCode even if postal_code already set
  if (situsCity) city_name = String(situsCity).toUpperCase();
  if (typeof situsZipCode === "string" && situsZipCode.trim()) {
    const parts = situsZipCode.split("-");
    const zip5 = parts[0] || null;
    const zip4 = parts[1] || null;
    if (zip5) postal_code = zip5; // keep consistent with situs
    if (zip4) plus_four_postal_code = zip4; // fill plus-four when available
  }

  // County mapping
  let county_name = null;
  if (typeof countyJurisdiction === "string" && countyJurisdiction.trim()) {
    const cj = countyJurisdiction.trim().toLowerCase();
    if (cj === "broward") county_name = "Broward";
    else if (cj === "miami dade" || cj === "miami-dade" || cj === "miami_dade")
      county_name = "Miami Dade";
    else if (cj === "palm beach") county_name = "Palm Beach";
    else county_name = null;
  }

  return {
    street_number: street_number || null,
    street_pre_directional_text: street_pre_directional_text || null,
    street_name: street_name || null,
    street_suffix_type: street_suffix_type || null,
    street_post_directional_text: null,
    city_name: city_name || null,
    municipality_name: null,
    state_code: state_code || null,
    postal_code: postal_code || null,
    plus_four_postal_code: plus_four_postal_code || null,
    country_code: null,
    county_name: county_name || null,
    latitude: null,
    longitude: null,
    unit_identifier: null,
    route_number: null,
    township: null,
    range: null,
    section: null,
    block: null,
    lot: null,
  };
}

function mapUnitsType(units) {
  const n = parseIntSafe(units);
  if (n === 1) return "One";
  if (n === 2) return "Two";
  if (n === 3) return "Three";
  if (n === 4) return "Four";
  return null;
}

function detectPropertyType(useCode, useCodeName) {
  const src = (useCodeName || useCode || "").toLowerCase();
  if (!src) return null;
  if (src.includes("single family")) return "SingleFamily";
  if (src.includes("duplex")) return "Duplex";
  if (src.includes("townhouse")) return "Townhouse";
  return null;
}

function parseLotSqft(landCalcFact1) {
  if (!landCalcFact1) return null;
  const m = String(landCalcFact1)
    .replace(/,/g, "")
    .match(/(\d+(?:\.\d+)?)\s*sq\s*ft/i);
  if (m) return parseIntSafe(m[1]);
  const n = parseIntSafe(String(landCalcFact1).replace(/[^0-9]/g, ""));
  return n || null;
}

const categories = [
  { key: "SingleFamily", patterns: [/Single Family/i, /Zero Lot Line/i] },
  { key: "Condominium", patterns: [/Condominium/i] },
  { key: "Cooperative", patterns: [/Cooperatives?/i] },
  { key: "Modular", patterns: [/Modular/i] },
  { key: "ManufacturedHousingSingleWide", patterns: [/Manufactured.*Single/i] },
  { key: "ManufacturedHousingMultiWide", patterns: [/Manufactured.*Double|Triple/i] },
  { key: "ManufacturedHousing", patterns: [/Manufactured/i] }, // keep after single/multi
  { key: "Pud", patterns: [/PUD/i] },
  { key: "Timeshare", patterns: [/Timeshare|Interval Ownership/i] },
  { key: "2Units", patterns: [/\b2 units\b/i] },
  { key: "3Units", patterns: [/\b3 units\b/i, /Triplex/i] },
  { key: "4Units", patterns: [/\b4 units\b/i, /Quad/i] },
  { key: "TwoToFourFamily", patterns: [/2 units|3 units|4 units|Duplex|Triplex|Quad/i] },
  { key: "MultipleFamily", patterns: [/Multi[- ]?family/i] },
  { key: "DetachedCondominium", patterns: [/Detached Condominium/i] },
  { key: "Duplex", patterns: [/Duplex/i] },
  { key: "Townhouse", patterns: [/Townhouse|Townhome/i] },
  { key: "NonWarrantableCondo", patterns: [/Condominium.*not suitable/i] },
  { key: "VacantLand", patterns: [/^Vacant|Submerged/i] },
  { key: "Retirement", patterns: [/Retirement/i] },
  { key: "MiscellaneousResidential", patterns: [/Miscellaneous residential/i] },
  { key: "ResidentialCommonElementsAreas", patterns: [/Common Area/i] },
  { key: "MobileHome", patterns: [/Mobile Home/i] },
];
 
// Function to map a given useCode to category
function mapUseCode(useCode) {
  for (const { key, patterns } of categories) {
    if (patterns.some(p => p.test(useCode))) {
      return key;
    }
  }
  return "null";
}

function main() {
  ensureDir("data");

  const input = readJSON("input.json");
  const unaddr = readJSON("unnormalized_address.json");
  const seed = readJSON("property_seed.json");

  let ownersData = null;
  let utilitiesData = null;
  let layoutData = null;
  try {
    ownersData = readJSON(path.join("owners", "owner_data.json"));
  } catch {}
  try {
    utilitiesData = readJSON(path.join("owners", "utilities_data.json"));
  } catch {}
  try {
    layoutData = readJSON(path.join("owners", "layout_data.json"));
  } catch {}

  const d = input && input.d ? input.d : {};
  const parcelInfo =
    Array.isArray(d.parcelInfok__BackingField) &&
    d.parcelInfok__BackingField.length
      ? d.parcelInfok__BackingField[0]
      : {};

  // Property
  const property = {
    parcel_identifier: parcelInfo.folioNumber || parcelId || "",
    livable_floor_area:
      parcelInfo.bldgUnderAirFootage != null
        ? String(parcelInfo.bldgUnderAirFootage)
        : null,
    total_area:
      parcelInfo.bldgTotSqFootage != null
        ? String(parcelInfo.bldgTotSqFootage)
        : null,
    area_under_air:
      parcelInfo.bldgUnderAirFootage != null
        ? String(parcelInfo.bldgUnderAirFootage)
        : null,
    number_of_units: parseIntSafe(parcelInfo.units),
    number_of_units_type: mapUnitsType(parcelInfo.units),
    property_structure_built_year: parseIntSafe(parcelInfo.actualAge),
    property_effective_built_year: parseIntSafe(parcelInfo.effectiveAge),
    property_type : mapUseCode(parcelInfo.useCode),
    property_legal_description_text: parcelInfo.legal
      ? String(parcelInfo.legal).trim()
      : null,
    subdivision: parcelInfo.legal ? String(parcelInfo.legal).trim() : null,
    zoning: parcelInfo.landCalcZoning || null,
  };
  writeJSON("data/property.json", property);

  // Address
  const fullAddr = unaddr && unaddr.full_address ? unaddr.full_address : null;
  const addrObj = extractAddress(
    fullAddr,
    parcelInfo.situsCity,
    parcelInfo.situsZipCode,
    unaddr && unaddr.county_jurisdiction,
  );
  writeJSON("data/address.json", addrObj);

  // Lot
  const lot = {
    lot_type: null,
    lot_length_feet: null,
    lot_width_feet: null,
    lot_area_sqft: parseLotSqft(parcelInfo.landCalcFact1),
    lot_size_acre: null,
    view: null,
    landscaping_features: null,
    fencing_type: null,
    fence_height: null,
    fence_length: null,
    driveway_material: null,
    driveway_condition: null,
    lot_condition_issues: null,
  };
  writeJSON("data/lot.json", lot);

  // Tax history
  const currentTaxYear = parseIntSafe(
    unaddr && unaddr.source_http_request && unaddr.source_http_request.json
      ? unaddr.source_http_request.json.taxyear
      : null,
  );

  function writeTaxRecord(index, yearVals) {
    const taxObj = {
      tax_year: yearVals.tax_year,
      property_assessed_value_amount: parseCurrencyToNumber(
        yearVals.assessedValue,
      ),
      property_market_value_amount: parseCurrencyToNumber(yearVals.justValue),
      property_building_amount: parseCurrencyToNumber(yearVals.bldgValue),
      property_land_amount: parseCurrencyToNumber(yearVals.landValue),
      property_taxable_value_amount: parseCurrencyToNumber(
        yearVals.taxableValue,
      ),
      monthly_tax_amount: null,
      yearly_tax_amount: parseCurrencyToNumber(yearVals.yearlyTaxAmount),
      period_start_date: null,
      period_end_date: null,
      first_year_on_tax_roll: null,
      first_year_building_on_tax_roll: null,
    };
    writeJSON(`data/tax_${index}.json`, taxObj);
  }

  if (currentTaxYear) {
    writeTaxRecord(1, {
      tax_year: currentTaxYear,
      assessedValue: parcelInfo.sohValue,
      justValue: parcelInfo.justValue,
      bldgValue: parcelInfo.bldgValue,
      landValue: parcelInfo.landValue,
      taxableValue: parcelInfo.taxableAmountCounty || parcelInfo.sohValue,
      yearlyTaxAmount: null,
    });

    if (
      parcelInfo.sohLastYearValue ||
      parcelInfo.justLastYearValue ||
      parcelInfo.bldgLastYearValue ||
      parcelInfo.landLastYearValue
    ) {
      writeTaxRecord(2, {
        tax_year: currentTaxYear - 1,
        assessedValue: parcelInfo.sohLastYearValue,
        justValue: parcelInfo.justLastYearValue,
        bldgValue: parcelInfo.bldgLastYearValue,
        landValue: parcelInfo.landLastYearValue,
        taxableValue: parcelInfo.sohLastYearValue,
        yearlyTaxAmount: parcelInfo.assessedLastYearValue,
      });
    }

    if (
      parcelInfo.sohLastTwoYearsValue ||
      parcelInfo.justLastTwoYearsValue ||
      parcelInfo.bldgLastTwoYearsValue ||
      parcelInfo.landLastTwoYearsValue
    ) {
      writeTaxRecord(3, {
        tax_year: currentTaxYear - 2,
        assessedValue: parcelInfo.sohLastTwoYearsValue,
        justValue: parcelInfo.justLastTwoYearsValue,
        bldgValue: parcelInfo.bldgLastTwoYearsValue,
        landValue: parcelInfo.landLastTwoYearsValue,
        taxableValue: parcelInfo.sohLastTwoYearsValue,
        yearlyTaxAmount: parcelInfo.assessedLastTwoYearsValue,
      });
    }
  } else {
    const tax = {
      tax_year: null,
      property_assessed_value_amount: parseCurrencyToNumber(
        parcelInfo.sohValue,
      ),
      property_market_value_amount: parseCurrencyToNumber(parcelInfo.justValue),
      property_building_amount: parseCurrencyToNumber(parcelInfo.bldgValue),
      property_land_amount: parseCurrencyToNumber(parcelInfo.landValue),
      property_taxable_value_amount: parseCurrencyToNumber(
        parcelInfo.taxableAmountCounty,
      ),
      monthly_tax_amount: null,
      yearly_tax_amount: null,
      period_start_date: null,
      period_end_date: null,
      first_year_on_tax_roll: null,
      first_year_building_on_tax_roll: null,
    };
    writeJSON("data/tax_1.json", tax);
  }

  // Sales and Deeds
  const sales = [];
  const deeds = [];
  for (let i = 1; i <= 5; i++) {
    const dateRaw = parcelInfo[`saleDate${i}`];
    const date = normalizeDate(dateRaw);
    const price = parcelInfo[`stampAmount${i}`];
    const deedType = parcelInfo[`deedType${i}`];
    if (date || price) {
      const s = {
        ownership_transfer_date: date || null,
        purchase_price_amount: parseCurrencyToNumber(price),
      };
      sales.push({ index: i, ...s });
      writeJSON(`data/sales_${i}.json`, s);
    }
    if (deedType) {
      const djson = { deed_type: deedType };
      deeds.push({ index: i, ...djson });
      writeJSON(`data/deed_${i}.json`, djson);
    }
  }

  // Owners relationships
  if (ownersData && ownersData[`property_${parcelInfo.folioNumber}`]) {
    const od = ownersData[`property_${parcelInfo.folioNumber}`];
    const currentOwners =
      od.owners_by_date && od.owners_by_date.current
        ? od.owners_by_date.current
        : [];
    if (Array.isArray(currentOwners) && currentOwners.length) {
      const owner = currentOwners[0];
      if (owner.type === "company") {
        const company = { name: owner.name || null };
        writeJSON("data/company_1.json", company);
        if (fs.existsSync("data/sales_1.json")) {
          writeJSON("data/relationship_sales_company.json", {
            to: { "/": "./company_1.json" },
            from: { "/": "./sales_1.json" },
          });
        }
      } else if (owner.type === "person") {
        const person = owner.person || {};
        writeJSON("data/person_1.json", person);
        if (fs.existsSync("data/sales_1.json")) {
          writeJSON("data/relationship_sales_person.json", {
            to: { "/": "./person_1.json" },
            from: { "/": "./sales_1.json" },
          });
        }
      }

      // Historical owners mapping by date if provided
      if (od.owners_by_date) {
        Object.keys(od.owners_by_date).forEach((k) => {
          if (k === "current") return;
          const ownersArr = Array.isArray(od.owners_by_date[k])
            ? od.owners_by_date[k]
            : [];
          const isoKey = normalizeDate(k);
          const saleMatch = sales.find(
            (s) => s.ownership_transfer_date === isoKey,
          );
          if (saleMatch && ownersArr.length) {
            ownersArr.forEach((o, idx) => {
              const idxOut = idx + 2;
              if (o.type === "company") {
                writeJSON(`data/company_${idxOut}.json`, {
                  name: o.name || null,
                });
                writeJSON(
                  `data/relationship_sales_company_${saleMatch.index}_${idxOut}.json`,
                  {
                    to: { "/": `./company_${idxOut}.json` },
                    from: { "/": `./sales_${saleMatch.index}.json` },
                  },
                );
              } else if (o.type === "person") {
                writeJSON(`data/person_${idxOut}.json`, o.person || {});
                writeJSON(
                  `data/relationship_sales_person_${saleMatch.index}_${idxOut}.json`,
                  {
                    to: { "/": `./person_${idxOut}.json` },
                    from: { "/": `./sales_${saleMatch.index}.json` },
                  },
                );
              }
            });
          }
        });
      }
    }
  }

  // Deed→Sales relationships per index
  for (let i = 1; i <= 5; i++) {
    if (
      fs.existsSync(`data/deed_${i}.json`) &&
      fs.existsSync(`data/sales_${i}.json`)
    ) {
      const rel = {
        to: { "/": `./sales_${i}.json` },
        from: { "/": `./deed_${i}.json` },
      };
      writeJSON(`data/relationship_sales_deed_${i}.json`, rel);
      if (i === 1) writeJSON("data/relationship_sales_deed.json", rel);
    }
  }

  // Structure
  const structure = {
    architectural_style_type: null,
    attachment_type: null,
    exterior_wall_material_primary: null,
    exterior_wall_material_secondary: null,
    exterior_wall_condition: null,
    exterior_wall_insulation_type: null,
    flooring_material_primary: null,
    flooring_material_secondary: null,
    subfloor_material: null,
    flooring_condition: null,
    interior_wall_structure_material: null,
    interior_wall_surface_material_primary: null,
    interior_wall_surface_material_secondary: null,
    interior_wall_finish_primary: null,
    interior_wall_finish_secondary: null,
    interior_wall_condition: null,
    roof_covering_material: null,
    roof_underlayment_type: null,
    roof_structure_material: null,
    roof_design_type: null,
    roof_condition: null,
    roof_age_years: null,
    gutters_material: null,
    gutters_condition: null,
    roof_material_type: null,
    foundation_type: null,
    foundation_material: null,
    foundation_waterproofing: null,
    foundation_condition: null,
    ceiling_structure_material: null,
    ceiling_surface_material: null,
    ceiling_insulation_type: null,
    ceiling_height_average: null,
    ceiling_condition: null,
    exterior_door_material: null,
    interior_door_material: null,
    window_frame_material: null,
    window_glazing_type: null,
    window_operation_type: null,
    window_screen_material: null,
    primary_framing_material: null,
    secondary_framing_material: null,
    structural_damage_indicators: null,
    number_of_stories: null,
    finished_base_area: parseIntSafe(parcelInfo.bldgSqFT),
    finished_upper_story_area: null,
    finished_basement_area: null,
    unfinished_base_area: null,
    unfinished_upper_story_area: null,
    unfinished_basement_area: null,
    exterior_wall_condition_primary: null,
    exterior_wall_condition_secondary: null,
    exterior_wall_insulation_type_primary: null,
    exterior_wall_insulation_type_secondary: null,
    roof_date: null,
  };
  writeJSON("data/structure.json", structure);

  // Utility
  if (utilitiesData && utilitiesData[`property_${parcelInfo.folioNumber}`]) {
    const util = utilitiesData[`property_${parcelInfo.folioNumber}`];
    writeJSON("data/utility.json", util);
  }

  // Layouts
  if (
    layoutData &&
    layoutData[`property_${parcelInfo.folioNumber}`] &&
    Array.isArray(layoutData[`property_${parcelInfo.folioNumber}`].layouts)
  ) {
    const layouts = layoutData[`property_${parcelInfo.folioNumber}`].layouts;
    layouts.forEach((lay, idx) =>
      writeJSON(`data/layout_${idx + 1}.json`, lay),
    );
  }

  // Files for property images
  const imageUrls = new Set();
  if (parcelInfo.picturePath) imageUrls.add(parcelInfo.picturePath);
  if (Array.isArray(d.picturesListk__BackingField))
    d.picturesListk__BackingField.forEach((u) => {
      if (u) imageUrls.add(u);
    });
  let fIdx = 1;
  for (const url of imageUrls) {
    const name = path.basename(url.split("?")[0]);
    const ext = name.toLowerCase().endsWith(".png") ? "png" : "jpeg";
    const fileObj = {
      file_format: ext,
      name,
      original_url: url,
      ipfs_url: null,
      document_type: "PropertyImage",
    };
    writeJSON(`data/file_${fIdx}.json`, fileObj);
    fIdx++;
  }
}

main();
