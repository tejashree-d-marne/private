// Structure mapping script
// Reads input.json and writes owners/structure_data.json following the structure schema

const fs = require("fs");
const path = require("path");

function safeParseInt(v) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : null;
}

function main() {
  const inputPath = path.join(process.cwd(), "input.json");
  const raw = fs.readFileSync(inputPath, "utf-8");
  const data = JSON.parse(raw);

  const parcel =
    (data &&
      data.d &&
      Array.isArray(data.d.parcelInfok__BackingField) &&
      data.d.parcelInfok__BackingField[0]) ||
    {};
  const folio = parcel.folioNumber || "unknown";

  // Many structure attributes are not present in the input. We default unknowns to null to preserve schema compliance.
  // Conservative assumptions only when very safe (e.g., single family likely detached), otherwise null.
  const structure = {
    architectural_style_type: null,
    attachment_type: "Detached",
    exterior_wall_material_primary: null,
    exterior_wall_material_secondary: null,
    exterior_wall_condition: null,
    exterior_wall_insulation_type: null,
    flooring_material_primary: null,
    flooring_material_secondary: null,
    subfloor_material: null,
    flooring_condition: null,
    interior_wall_structure_material: null,
    interior_wall_surface_material_primary: null,
    interior_wall_surface_material_secondary: null,
    interior_wall_finish_primary: null,
    interior_wall_finish_secondary: null,
    interior_wall_condition: null,
    roof_covering_material: null,
    roof_underlayment_type: null,
    roof_structure_material: null,
    roof_design_type: null,
    roof_condition: null,
    roof_age_years: null,
    gutters_material: null,
    gutters_condition: null,
    roof_material_type: null,
    foundation_type: null,
    foundation_material: null,
    foundation_waterproofing: null,
    foundation_condition: null,
    ceiling_structure_material: null,
    ceiling_surface_material: null,
    ceiling_insulation_type: null,
    ceiling_height_average: null,
    ceiling_condition: null,
    exterior_door_material: null,
    interior_door_material: null,
    window_frame_material: null,
    window_glazing_type: null,
    window_operation_type: null,
    window_screen_material: null,
    primary_framing_material: null,
    secondary_framing_material: null,
    structural_damage_indicators: null,

    // Optional fields not required by schema, included when easily derivable
    number_of_stories: null,
    finished_base_area: safeParseInt(parcel.bldgSqFT),
    finished_upper_story_area: null,
    finished_basement_area: null,
    unfinished_base_area: null,
    unfinished_upper_story_area: null,
    unfinished_basement_area: null,

    exterior_wall_condition_primary: null,
    exterior_wall_condition_secondary: null,
    exterior_wall_insulation_type_primary: null,
    exterior_wall_insulation_type_secondary: null,
    roof_date: null,
    roof_material_type: null,
  };

  const outObj = {};
  outObj[`property_${folio}`] = structure;

  const outDir = path.join(process.cwd(), "owners");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, "structure_data.json");
  fs.writeFileSync(outPath, JSON.stringify(outObj, null, 2));
  console.log(`Wrote ${outPath}`);
}

main();
