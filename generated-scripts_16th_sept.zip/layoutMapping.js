// Layout mapping script
// Reads input.json and writes owners/layout_data.json following the layout schema

const fs = require("fs");
const path = require("path");

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function main() {
  const inputPath = path.join(process.cwd(), "input.json");
  const raw = fs.readFileSync(inputPath, "utf-8");
  const data = JSON.parse(raw);

  const parcel =
    (data &&
      data.d &&
      Array.isArray(data.d.parcelInfok__BackingField) &&
      data.d.parcelInfok__BackingField[0]) ||
    {};
  const folio = parcel.folioNumber || "unknown";

  const beds = parseInt(parcel.beds, 10) || 0;
  const baths = parseInt(parcel.baths, 10) || 0; // treat as full bathrooms count
  const bldgUnderAir = num(parcel.bldgUnderAirFootage);

  const layouts = [];
  // Represent each bedroom
  for (let i = 1; i <= beds; i++) {
    layouts.push({
      space_type: i === 1 ? "Primary Bedroom" : "Secondary Bedroom",
      space_index: i,
      flooring_material_type: null,
      size_square_feet: null,
      floor_level: null,
      has_windows: null,
      window_design_type: null,
      window_material_type: null,
      window_treatment_type: null,
      is_finished: true,
      furnished: null,
      paint_condition: null,
      flooring_wear: null,
      clutter_level: null,
      visible_damage: null,
      countertop_material: null,
      cabinet_style: null,
      fixture_finish_quality: null,
      design_style: null,
      natural_light_quality: null,
      decor_elements: null,
      pool_type: null,
      pool_equipment: null,
      spa_type: null,
      safety_features: null,
      view_type: null,
      lighting_features: null,
      condition_issues: null,
      is_exterior: false,
      pool_condition: null,
      pool_surface_type: null,
      pool_water_quality: null,
    });
  }

  // Represent each bathroom as Full Bathroom
  for (let j = 1; j <= baths; j++) {
    layouts.push({
      space_type: "Full Bathroom",
      space_index: beds + j,
      flooring_material_type: null,
      size_square_feet: null,
      floor_level: null,
      has_windows: null,
      window_design_type: null,
      window_material_type: null,
      window_treatment_type: null,
      is_finished: true,
      furnished: null,
      paint_condition: null,
      flooring_wear: null,
      clutter_level: null,
      visible_damage: null,
      countertop_material: null,
      cabinet_style: null,
      fixture_finish_quality: null,
      design_style: null,
      natural_light_quality: null,
      decor_elements: null,
      pool_type: null,
      pool_equipment: null,
      spa_type: null,
      safety_features: null,
      view_type: null,
      lighting_features: null,
      condition_issues: null,
      is_exterior: false,
      pool_condition: null,
      pool_surface_type: null,
      pool_water_quality: null,
    });
  }

  // Add a generic Living Room and Kitchen if size known
  layouts.push({
    space_type: "Living Room",
    space_index: beds + baths + 1,
    flooring_material_type: null,
    size_square_feet: null,
    floor_level: null,
    has_windows: null,
    window_design_type: null,
    window_material_type: null,
    window_treatment_type: null,
    is_finished: true,
    furnished: null,
    paint_condition: null,
    flooring_wear: null,
    clutter_level: null,
    visible_damage: null,
    countertop_material: null,
    cabinet_style: null,
    fixture_finish_quality: null,
    design_style: null,
    natural_light_quality: null,
    decor_elements: null,
    pool_type: null,
    pool_equipment: null,
    spa_type: null,
    safety_features: null,
    view_type: null,
    lighting_features: null,
    condition_issues: null,
    is_exterior: false,
    pool_condition: null,
    pool_surface_type: null,
    pool_water_quality: null,
  });
  layouts.push({
    space_type: "Kitchen",
    space_index: beds + baths + 2,
    flooring_material_type: null,
    size_square_feet: null,
    floor_level: null,
    has_windows: null,
    window_design_type: null,
    window_material_type: null,
    window_treatment_type: null,
    is_finished: true,
    furnished: null,
    paint_condition: null,
    flooring_wear: null,
    clutter_level: null,
    visible_damage: null,
    countertop_material: null,
    cabinet_style: null,
    fixture_finish_quality: null,
    design_style: null,
    natural_light_quality: null,
    decor_elements: null,
    pool_type: null,
    pool_equipment: null,
    spa_type: null,
    safety_features: null,
    view_type: null,
    lighting_features: null,
    condition_issues: null,
    is_exterior: false,
    pool_condition: null,
    pool_surface_type: null,
    pool_water_quality: null,
  });

  const outObj = {};
  outObj[`property_${folio}`] = { layouts };

  const outDir = path.join(process.cwd(), "owners");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, "layout_data.json");
  fs.writeFileSync(outPath, JSON.stringify(outObj, null, 2));
  console.log(`Wrote ${outPath}`);
}

main();
