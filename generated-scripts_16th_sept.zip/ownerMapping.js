// ownerMapping.js
// Transform a single property's HTML or JSON into the required owners JSON schema.
// - Reads input.json from the working directory
// - Extracts owner candidates (current and historical) via heuristics
// - Classifies owners (person/company), deduplicates, and groups by date (if any)
// - Determines a property ID (falls back to unknown_id)
// - Writes owners/owner_data.json and prints the JSON to stdout

const fs = require("fs");

// Utility: Title Case for person name components
function toTitleCase(s) {
  return s.toLowerCase().replace(/\b([a-z])/g, (m, p1) => p1.toUpperCase());
}

// Utility: normalize name for deduplication
function normalizeName(name) {
  return (name || "").trim().toLowerCase().replace(/\s+/g, " ");
}

// Company detection tokens (case-insensitive)
const COMPANY_TOKENS = [
  "inc",
  "llc",
  "l.l.c",
  "ltd",
  "limited",
  "foundation",
  "alliance",
  "solutions",
  "corp",
  "corporation",
  "co",
  "company",
  "services",
  "service",
  "trust",
  "tr",
  "partners",
  "lp",
  "llp",
  "plc",
  "pc",
  "bank",
  "association",
  "hoa",
  "properties",
  "holdings",
  "investment",
  "investments",
  "group",
  "fund",
  "estate",
  "realty",
];

function isCompanyName(name) {
  const n = (name || "").toLowerCase();
  return COMPANY_TOKENS.some((tok) =>
    new RegExp(`(^|[^a-z])${tok}([^a-z]|$)`, "i").test(n),
  );
}

function cleanName(raw) {
  if (typeof raw !== "string") return "";
  let s = raw.replace(/[\u00A0\t\r\n]+/g, " ");
  s = s.replace(/\s+/g, " ").trim();
  // Strip surrounding punctuation
  s = s.replace(/^[,;:\-\s]+|[,;:\-\s]+$/g, "");
  return s;
}

// Split joint names on '&' or ' and '
function splitJointNames(name) {
  const s = name
    .replace(/\s*&\s*/g, " & ")
    .replace(/\s+/g, " ")
    .trim();
  if (s.includes(" & "))
    return s
      .split(" & ")
      .map((x) => x.trim())
      .filter(Boolean);
  if (/\sand\s/i.test(s))
    return s
      .split(/\sand\s/i)
      .map((x) => x.trim())
      .filter(Boolean);
  return [s];
}

function parsePersonName(name) {
  const parts = name.split(/\s+/).filter(Boolean);
  if (parts.length < 2) return null; // require first and last
  const first = toTitleCase(parts[0]);
  const last = toTitleCase(parts[parts.length - 1]);
  const middle = parts.slice(1, -1).join(" ");
  return {
    type: "person",
    first_name: first,
    last_name: last,
    middle_name: middle ? toTitleCase(middle) : null,
  };
}

function parseCompanyName(name) {
  return { type: "company", name: name };
}

// Reformat dates to YYYY-MM-DD if possible; otherwise return null
function toISODate(s) {
  if (typeof s !== "string") return null;
  const t = s.trim();
  // Match MM/DD/YYYY or M/D/YYYY
  let m = t.match(/^([0-1]?\d)\/([0-3]?\d)\/(\d{4})$/);
  if (m) {
    const mm = m[1].padStart(2, "0");
    const dd = m[2].padStart(2, "0");
    const yyyy = m[3];
    return `${yyyy}-${mm}-${dd}`;
  }
  // Match YYYY-MM-DD already
  m = t.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) return t;
  return null;
}

// Extract candidate owner strings from a JSON structure by scanning keys
function extractOwnersFromJSON(obj) {
  const candidates = [];
  (function walk(node, pathKey) {
    if (node && typeof node === "object") {
      if (Array.isArray(node)) {
        for (const it of node) walk(it, pathKey);
      } else {
        for (const [k, v] of Object.entries(node)) {
          const key = k.toLowerCase();
          const looksLikeOwnerKey = /owner/.test(key);
          if (looksLikeOwnerKey && typeof v === "string") {
            candidates.push({ raw: v, contextKey: k });
          } else if (looksLikeOwnerKey && typeof v === "number") {
            // numbers like ownerAlertVerified are not owner names; ignore
          } else {
            walk(v, k);
          }
        }
      }
    }
  })(obj, "");
  return candidates;
}

// Extract date-like values from JSON structure (returns array of ISO dates)
function extractDatesFromJSON(obj) {
  const dates = [];
  (function walk(node) {
    if (node && typeof node === "object") {
      if (Array.isArray(node)) {
        for (const it of node) walk(it);
      } else {
        for (const [k, v] of Object.entries(node)) {
          const key = k.toLowerCase();
          if (
            (/date/.test(key) || /sale/.test(key) || /deed/.test(key)) &&
            typeof v === "string"
          ) {
            const iso = toISODate(v);
            if (iso) dates.push(iso);
          } else {
            walk(v);
          }
        }
      }
    }
  })(obj);
  // Unique + sort ascending
  const uniq = Array.from(new Set(dates));
  uniq.sort();
  return uniq;
}

function classifyAndStructureOwners(rawNames) {
  const seen = new Set();
  const validOwners = [];
  const invalidOwners = [];

  for (const cand of rawNames) {
    const cleaned = cleanName(cand.raw);
    if (!cleaned) continue;

    // Handle joint names
    const parts = splitJointNames(cleaned);
    for (const part of parts) {
      const norm = normalizeName(part);
      if (!norm) continue;
      if (seen.has(norm)) continue;

      let ownerObj = null;
      if (isCompanyName(part)) {
        ownerObj = parseCompanyName(part);
      } else {
        const person = parsePersonName(part);
        if (person) {
          ownerObj = person;
        } else {
          invalidOwners.push({
            raw: part,
            reason: "Unable to classify as person or company",
          });
        }
      }

      if (ownerObj) {
        validOwners.push(ownerObj);
        seen.add(norm);
      }
    }
  }

  return { validOwners, invalidOwners };
}

function extractPropertyIdFromJSON(obj) {
  // Preferred candidates in order
  const preferredKeys = [
    "folioNumber",
    "folio",
    "parcelNumber",
    "parcel_id",
    "parcelid",
    "apn",
    "property_id",
    "propertyid",
    "propid",
    "id",
  ].map((k) => k.toLowerCase());

  let found = null;
  (function walk(node) {
    if (found) return;
    if (node && typeof node === "object") {
      if (Array.isArray(node)) {
        for (const it of node) {
          if (!found) walk(it);
        }
      } else {
        // Check preferred keys first
        for (const pk of preferredKeys) {
          for (const [k, v] of Object.entries(node)) {
            if (
              k.toLowerCase() === pk &&
              (typeof v === "string" || typeof v === "number")
            ) {
              found = String(v).trim();
              if (found) return;
            }
          }
        }
        // Otherwise, search any key with id/folio/parcel/apn
        for (const [k, v] of Object.entries(node)) {
          if (found) break;
          const key = k.toLowerCase();
          const looksLikeId =
            /(folio|parcel|apn|property[_\s]?id|propid|^id$)/.test(key);
          if (looksLikeId && (typeof v === "string" || typeof v === "number")) {
            const s = String(v).trim();
            if (s) {
              found = s;
              break;
            }
          } else if (v && typeof v === "object") {
            walk(v);
          }
        }
      }
    }
  })(obj);

  return found || "unknown_id";
}

// Group owners by date: if dates provided and can be associated, use them; otherwise assign to 'current'.
// In this generalized transformer (JSON path), we only have explicit owner fields without dates; so assign all to current.
function buildOwnersByDate(validOwners, dates) {
  // Only current known; if we had historical owner segments with dates, we'd assign accordingly.
  const ownersByDate = { current: validOwners };
  return ownersByDate;
}

// For potential HTML input, provide minimalist extraction using cheerio if needed.
function tryExtractFromHTML(html) {
  // Lazy require to avoid dependency if not needed
  const cheerio = require("cheerio");
  const $ = cheerio.load(html);

  const ownerCandidates = [];
  // Heuristic 1: table-like structures with header containing 'owner'
  $("table").each((_, tbl) => {
    const rows = $(tbl).find("tr");
    rows.each((__, tr) => {
      const cells = $(tr).find("th,td");
      cells.each((i, cell) => {
        const txt = $(cell).text().trim();
        if (/owner/i.test(txt)) {
          // candidate from next cell in row
          if (i + 1 < cells.length) {
            const nextTxt = $(cells[i + 1])
              .text()
              .trim();
            if (nextTxt)
              ownerCandidates.push({ raw: nextTxt, contextKey: "table" });
          }
        }
      });
    });
  });

  // Heuristic 2: labeled fields like 'Owner Name:'
  $("*").each((_, el) => {
    const txt = $(el).text().trim();
    if (/owner\s*name\s*[:\-]/i.test(txt)) {
      const name = txt.replace(/.*owner\s*name\s*[:\-]\s*/i, "").trim();
      if (name) ownerCandidates.push({ raw: name, contextKey: "label" });
    }
  });

  // Extract date-like strings present in the DOM
  const dates = new Set();
  $("*").each((_, el) => {
    const txt = $(el).text().trim();
    const m = txt.match(/\b(\d{1,2}\/\d{1,2}\/\d{4}|\d{4}-\d{2}-\d{2})\b/g);
    if (m) {
      for (const d of m) {
        const iso = toISODate(d);
        if (iso) dates.add(iso);
      }
    }
  });

  return { ownerCandidates, dates: Array.from(dates).sort() };
}

// Main execution: read input.json, parse JSON or HTML, and output result
const inputRaw = fs.readFileSync("input.json", "utf8");
const trimmed = inputRaw.trim();

let ownerCandidates = [];
let dates = [];
let propertyId = "unknown_id";

if (trimmed.startsWith("<")) {
  // HTML path
  const { ownerCandidates: oc, dates: ds } = tryExtractFromHTML(trimmed);
  ownerCandidates = oc;
  dates = ds;
  // Property ID from HTML: try basic heuristics
  // We won't parse specific IDs here due to variability; keep unknown_id unless an obvious numeric ID near a label is present.
} else {
  // JSON path
  const data = JSON.parse(trimmed);
  ownerCandidates = extractOwnersFromJSON(data);
  dates = extractDatesFromJSON(data);
  propertyId = extractPropertyIdFromJSON(data);
}

const { validOwners, invalidOwners } =
  classifyAndStructureOwners(ownerCandidates);
const ownersByDate = buildOwnersByDate(validOwners, dates);

const key = `property_${propertyId || "unknown_id"}`;
const output = {};
output[key] = {
  owners_by_date: ownersByDate,
  invalid_owners: invalidOwners,
};

// Ensure directory and write file
fs.mkdirSync("owners", { recursive: true });
fs.writeFileSync("owners/owner_data.json", JSON.stringify(output, null, 2));

// Print to stdout
console.log(JSON.stringify(output, null, 2));
