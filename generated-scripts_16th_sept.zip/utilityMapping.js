// Utility mapping script
// Reads input.json and writes owners/utilities_data.json following the utility schema

const fs = require("fs");
const path = require("path");

function main() {
  const inputPath = path.join(process.cwd(), "input.json");
  const raw = fs.readFileSync(inputPath, "utf-8");
  const data = JSON.parse(raw);
  const parcel =
    (data &&
      data.d &&
      Array.isArray(data.d.parcelInfok__BackingField) &&
      data.d.parcelInfok__BackingField[0]) ||
    {};
  const folio = parcel.folioNumber || "unknown";

  // With limited information, we set utilities to null or reasonable defaults per enums when present.
  const utility = {
    cooling_system_type: null,
    heating_system_type: null,
    public_utility_type: null,
    sewer_type: null,
    water_source_type: null,
    plumbing_system_type: null,
    plumbing_system_type_other_description: null,
    electrical_panel_capacity: null,
    electrical_wiring_type: null,
    hvac_condensing_unit_present: null,
    electrical_wiring_type_other_description: null,
    solar_panel_present: false,
    solar_panel_type: null,
    solar_panel_type_other_description: null,
    smart_home_features: null,
    smart_home_features_other_description: null,
    hvac_unit_condition: null,
    solar_inverter_visible: false,
    hvac_unit_issues: null,
  };

  const outObj = {};
  outObj[`property_${folio}`] = utility;

  const outDir = path.join(process.cwd(), "owners");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, "utilities_data.json");
  fs.writeFileSync(outPath, JSON.stringify(outObj, null, 2));
  console.log(`Wrote ${outPath}`);
}

main();
