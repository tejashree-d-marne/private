// ownerMapping.js
// Transform an HTML (or text-embedded) file containing a single property's data into the required JSON schema.
// Uses only cheerio for HTML parsing and Node built-ins for file I/O and JSON processing.

const fs = require("fs");
const path = require("path");
const cheerio = require("cheerio");

// Read input file as raw text
const inputPath = path.join(process.cwd(), "input.json");
const raw = fs.readFileSync(inputPath, "utf8");

// Load into cheerio and extract text content (works even if the file is raw JSON or HTML)
const $ = cheerio.load(raw);
const docText = $.root().text();

// Attempt to interpret the content as JSON text and extract values using vanilla JS
const data = JSON.parse(docText);

// Utility: Recursively traverse any object/array and collect key-value pairs meeting heuristics
function traverse(obj, cb, parentPath = []) {
  if (Array.isArray(obj)) {
    for (let i = 0; i < obj.length; i++) {
      traverse(obj[i], cb, parentPath.concat(i));
    }
    return;
  }
  if (obj && typeof obj === "object") {
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      cb(k, v, parentPath);
      traverse(v, cb, parentPath.concat(k));
    }
  }
}

// Heuristics for company identification (case-insensitive)
const companyWords = [
  "inc",
  "inc.",
  "llc",
  "l.l.c",
  "ltd",
  "ltd.",
  "foundation",
  "alliance",
  "solutions",
  "corp",
  "corp.",
  "co",
  "co.",
  "services",
  "trust",
  "partners",
  "holdings",
  "group",
  "association",
  "assn",
  "bank",
  "national association",
  "n.a.",
  "na",
  "fund",
  "university",
  "church",
  "plc",
  "s.a.",
  "gmbh",
  "b.v.",
  "n.v.",
  "limited",
  "lp",
  "llp",
  "pc",
  "p.c.",
  "pa",
  "p.a.",
  "tr",
  "tr.",
];
const companyRegex = new RegExp(
  "(?:(?:^|\\b)(" +
    companyWords
      .map((w) => w.replace(/[.*+?^${}()|[\\]\\\\]/g, (r) => "\\" + r))
      .join("|") +
    ")(?:$|\\b))",
  "i",
);

function isLikelyCompany(name) {
  return companyRegex.test(name);
}

// Normalize name for deduplication
function normalizeName(str) {
  return String(str || "")
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase();
}

// Parse a person name from a raw string
function parsePersonName(rawName) {
  const name = String(rawName || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!name) return null;

  // Names with & per requirements: remove it and split as a single person
  if (name.includes("&")) {
    const cleaned = name.replace(/&/g, " ").replace(/\s+/g, " ").trim();
    const parts = cleaned.split(" ").filter(Boolean);
    if (parts.length >= 2) {
      const first_name = parts[0];
      const last_name = parts[parts.length - 1];
      const middle = parts.slice(1, -1).join(" ");
      return {
        type: "person",
        first_name,
        last_name,
        middle_name: middle ? middle : null,
      };
    }
    return null;
  }

  // Comma format: LAST, FIRST MIDDLE
  if (name.includes(",")) {
    const [left, right] = name.split(",");
    const last = (left || "").trim();
    const rightParts = (right || "").trim().split(/\s+/).filter(Boolean);
    if (last && rightParts.length >= 1) {
      const first = rightParts[0];
      const middle = rightParts.slice(1).join(" ");
      return {
        type: "person",
        first_name: first,
        last_name: last,
        middle_name: middle ? middle : null,
      };
    }
    return null;
  }

  // Space-separated: First Middle Last
  const parts = name.split(" ").filter(Boolean);
  if (parts.length >= 2) {
    const first = parts[0];
    const last = parts[parts.length - 1];
    const middle = parts.slice(1, -1).join(" ");
    return {
      type: "person",
      first_name: first,
      last_name: last,
      middle_name: middle ? middle : null,
    };
  }
  return null;
}

// Convert a variety of date strings to YYYY-MM-DD if possible
function toISODate(str) {
  const s = String(str || "").trim();
  // Try formats like MM/DD/YYYY
  const m1 = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m1) {
    const [_, mm, dd, yyyy] = m1;
    const m = String(mm).padStart(2, "0");
    const d = String(dd).padStart(2, "0");
    return `${yyyy}-${m}-${d}`;
  }
  // Already ISO
  const m2 = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m2) return s;
  return null;
}

// Helper to stringify a parent path for scope matching
function pathStr(arr) {
  return arr
    .map((x) => (typeof x === "number" ? `#${x}` : String(x)))
    .join("/");
}

// Collect candidates
const ownerNameCandidates = [];
const dateCandidatesByScope = new Map(); // scopeStr -> Set of ISO dates
const idCandidates = [];
const ownerScopes = new Set();

traverse(data, (key, value, parentPath) => {
  const k = String(key || "");
  const scope = pathStr(parentPath);

  // Owner fields: any key containing 'owner' and 'name' OR starts with ownerName, owner_name etc.
  if (/owner/i.test(k) && /name/i.test(k)) {
    if (typeof value === "string" && value.trim()) {
      ownerNameCandidates.push(value.trim());
      ownerScopes.add(scope);
    }
  } else if (
    /^owner\w*/i.test(k) &&
    typeof value === "string" &&
    value.trim()
  ) {
    // keys like owner, owner1 etc.
    if (/owner/i.test(k)) {
      ownerNameCandidates.push(value.trim());
      ownerScopes.add(scope);
    }
  }

  // IDs: look for likely property id fields
  if (/folio|prop(er)?ty\s*id|prop(id)?|parcel\s*id|account\s*id/i.test(k)) {
    if (typeof value === "string" && value.trim()) {
      idCandidates.push(value.trim());
    }
  }
});

// After collecting owner scopes, collect dates only within those scopes
traverse(data, (key, value, parentPath) => {
  const k = String(key || "");
  if (!/date/i.test(k)) return;
  const scope = pathStr(parentPath);
  if (!ownerScopes.has(scope)) return;
  if (typeof value === "string" && value.trim()) {
    const iso = toISODate(value.trim());
    if (!iso) return;
    if (!dateCandidatesByScope.has(scope))
      dateCandidatesByScope.set(scope, new Set());
    dateCandidatesByScope.get(scope).add(iso);
  }
});

// Prefer a folio-like id if found
let propertyId = "unknown_id";
const folio = idCandidates.find((v) => /\d+[a-z]*[a-z0-9]*/i.test(v)) || null;
if (folio) propertyId = folio;

// Deduplicate owner names
const seenRaw = new Set();
const uniqueOwnerNames = [];
for (const nm of ownerNameCandidates) {
  const norm = normalizeName(nm);
  if (!norm) continue;
  if (seenRaw.has(norm)) continue;
  seenRaw.add(norm);
  uniqueOwnerNames.push(nm);
}

// Classify owners
const validOwners = [];
const invalidOwners = [];

for (const rawName of uniqueOwnerNames) {
  const name = rawName.trim();
  if (!name) continue;

  if (isLikelyCompany(name)) {
    // Company
    validOwners.push({ type: "company", name: name });
    continue;
  }

  // Person
  const person = parsePersonName(name);
  if (person && person.first_name && person.last_name) {
    validOwners.push(person);
  } else {
    invalidOwners.push({
      raw: name,
      reason: "Unclassified or missing required fields",
    });
  }
}

// Build owners_by_date
const ownersByDate = {};

// Find the latest date among owner-associated scopes, if any
let latestDate = null;
for (const set of dateCandidatesByScope.values()) {
  const dates = Array.from(set).sort(); // ISO dates sort lexicographically
  if (dates.length) {
    const last = dates[dates.length - 1];
    if (!latestDate || last > latestDate) latestDate = last;
  }
}

if (latestDate) {
  ownersByDate[latestDate] = validOwners;
}

// Always include current owners
ownersByDate["current"] = validOwners;

// Compose final output
const output = {};
output[`property_${propertyId}`] = {
  owners_by_date: ownersByDate,
  invalid_owners: invalidOwners,
};

// Ensure output directory exists and write file
const outDir = path.join(process.cwd(), "owners");
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, "owner_data.json");
fs.writeFileSync(outPath, JSON.stringify(output, null, 2), "utf8");

// Print the result JSON only
console.log(JSON.stringify(output, null, 2));
