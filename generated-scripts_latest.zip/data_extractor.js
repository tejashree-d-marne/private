const fs = require("fs");
const path = require("path");

function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
}

function parseCurrency(val) {
  if (val == null) return null;
  if (typeof val === "number") return val;
  if (typeof val !== "string") return null;
  const cleaned = val.replace(/[$,\s]/g, "");
  if (!cleaned) return null;
  const num = Number(cleaned);
  return Number.isFinite(num) ? Number(num.toFixed(2)) : null;
}

function toISO(dateStr) {
  if (!dateStr || typeof dateStr !== "string") return null;
  // Handle already ISO
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return dateStr;
  // Handle MM/DD/YYYY
  const m = dateStr.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (m) {
    const [_, mm, dd, yyyy] = m;
    return `${yyyy}-${mm}-${dd}`;
  }
  return null;
}

function titleCaseName(s) {
  if (!s) return null;
  // Lowercase then uppercase first letter of each word/segment
  return s
    .toString()
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function extractFromInput(input) {
  const d = input && input.d ? input.d : {};
  const parcel =
    Array.isArray(d.parcelInfok__BackingField) &&
    d.parcelInfok__BackingField.length > 0
      ? d.parcelInfok__BackingField[0]
      : {};
  return { d, parcel };
}
const categories = [
  { key: "SingleFamily", patterns: [/Single Family/i, /Zero Lot Line/i] },
  { key: "Condominium", patterns: [/Condominium/i] },
  { key: "Cooperative", patterns: [/Cooperatives?/i] },
  { key: "Modular", patterns: [/Modular/i] },
  { key: "ManufacturedHousingSingleWide", patterns: [/Manufactured.*Single/i] },
  { key: "ManufacturedHousingMultiWide", patterns: [/Manufactured.*Double|Triple/i] },
  { key: "ManufacturedHousing", patterns: [/Manufactured/i] }, // keep after single/multi
  { key: "Pud", patterns: [/PUD/i] },
  { key: "Timeshare", patterns: [/Timeshare|Interval Ownership/i] },
  { key: "2Units", patterns: [/\b2 units\b/i] },
  { key: "3Units", patterns: [/\b3 units\b/i, /Triplex/i] },
  { key: "4Units", patterns: [/\b4 units\b/i, /Quad/i] },
  { key: "TwoToFourFamily", patterns: [/2 units|3 units|4 units|Duplex|Triplex|Quad/i] },
  { key: "MultipleFamily", patterns: [/Multi[- ]?family/i] },
  { key: "DetachedCondominium", patterns: [/Detached Condominium/i] },
  { key: "Duplex", patterns: [/Duplex/i] },
  { key: "Townhouse", patterns: [/Townhouse|Townhome/i] },
  { key: "NonWarrantableCondo", patterns: [/Condominium.*not suitable/i] },
  { key: "VacantLand", patterns: [/^Vacant|Submerged/i] },
  { key: "Retirement", patterns: [/Retirement/i] },
  { key: "MiscellaneousResidential", patterns: [/Miscellaneous residential/i] },
  { key: "ResidentialCommonElementsAreas", patterns: [/Common Area/i] },
  { key: "MobileHome", patterns: [/Mobile Home/i] },
];
 
// Function to map a given useCode to category
function mapUseCode(useCode) {
  for (const { key, patterns } of categories) {
    if (patterns.some(p => p.test(useCode))) {
      return key;
    }
  }
  return "null";
}

function buildProperty(parcel) {
  const livable = parcel.bldgUnderAirFootage || parcel.bldgSqFT || null;
  const areaUnderAir = parcel.bldgUnderAirFootage || null;
  const numUnits = parcel.units
    ? Number(String(parcel.units).replace(/[^0-9]/g, ""))
    : null;
  let numUnitsType = null;
  if (Number.isFinite(numUnits)) {
    if (numUnits === 1) numUnitsType = "One";
    else if (numUnits === 2) numUnitsType = "Two";
    else if (numUnits === 3) numUnitsType = "Three";
    else if (numUnits === 4) numUnitsType = "Four";
    else if (numUnits >= 2 && numUnits <= 4) numUnitsType = "TwoToFour";
    else if (numUnits >= 1 && numUnits <= 4) numUnitsType = "OneToFour";
  }
  let propertyType = null;
  // if (parcel.useCode && /Condominium/i.test(parcel.useCode))
  //   propertyType = "Condominium";
  // Prefer explicit year strings if 4 digits
  const builtYear =
    parcel.actualAge && /\d{4}/.test(parcel.actualAge)
      ? Number(parcel.actualAge.match(/\d{4}/)[0])
      : null;
  const effectiveYear =
    parcel.effectiveAge && /\d{4}/.test(parcel.effectiveAge)
      ? Number(parcel.effectiveAge.match(/\d{4}/)[0])
      : null;

  const obj = {
    livable_floor_area: livable != null ? String(livable) : null,
    area_under_air: areaUnderAir != null ? String(areaUnderAir) : null,
    number_of_units: Number.isFinite(numUnits) ? numUnits : null,
    number_of_units_type: numUnitsType,
    parcel_identifier: parcel.folioNumber || "",
    property_legal_description_text: parcel.legal || null,
    property_structure_built_year: Number.isFinite(builtYear)
      ? builtYear
      : null,
    property_effective_built_year: Number.isFinite(effectiveYear)
      ? effectiveYear
      : null,
    property_type:  mapUseCode(parcel.useCode),
    subdivision: null,
    total_area: parcel.bldgTotSqFootage
      ? String(parcel.bldgTotSqFootage)
      : null,
    zoning: parcel.landCalcZoning || null,
    historic_designation: false,
  };
  return obj;
}

function mapStreetSuffix(word) {
  if (!word) return null;
  const w = word.trim().toUpperCase();
  const map = {
    COURT: "Ct",
    CT: "Ct",
    STREET: "St",
    ST: "St",
    AVENUE: "Ave",
    AVE: "Ave",
    ROAD: "Rd",
    RD: "Rd",
    BOULEVARD: "Blvd",
    BLVD: "Blvd",
    LANE: "Ln",
    LN: "Ln",
    DRIVE: "Dr",
    DR: "Dr",
  };
  return map[w] || null;
}

function buildAddress(parcel, unAddr) {
  const full = parcel.situsAddress1 || (unAddr && unAddr.full_address) || null;
  let streetNumber = parcel.situsStreetNumber || null;
  let preDir = null;
  let streetName = null;
  let suffix = null;
  let unit = null;

  if (full) {
    // Example: "12800 SW 7 COURT # 306G"
    const m = full.match(/^(\d+)\s+([NSEW]{1,2})\s+(.+)$/i);
    if (m) {
      streetNumber = streetNumber || m[1];
      preDir = m[2].toUpperCase();
      let rest = m[3];
      // Extract unit
      const um = rest.match(/#\s*([^\s]+)$/);
      if (um) {
        unit = um[1];
        rest = rest.replace(/#\s*[^\s]+$/, "").trim();
      }
      // Rest example: "7 COURT" => streetName: 7, suffix: Ct
      const parts = rest.split(/\s+/);
      if (parts.length >= 2) {
        streetName = parts.slice(0, parts.length - 1).join(" ");
        suffix = mapStreetSuffix(parts[parts.length - 1]);
      } else {
        streetName = rest;
      }
    }
  }

  const city =
    parcel.situsCity ||
    (unAddr &&
      unAddr.full_address &&
      (unAddr.full_address.split(",")[1] || "").trim().toUpperCase()) ||
    null;
  const state = "FL"; // From source context (Broward, FL)
  const postal = parcel.situsZipCode || null;
  const countyName =
    unAddr && unAddr.county_jurisdiction
      ? unAddr.county_jurisdiction.charAt(0).toUpperCase() +
        unAddr.county_jurisdiction.slice(1).toLowerCase()
      : null;

  return {
    street_number: streetNumber ? String(streetNumber) : null,
    street_pre_directional_text: preDir || null,
    street_name: streetName
      ? String(streetName).replace(/\s+/g, " ").trim()
      : null,
    street_suffix_type: suffix || null,
    street_post_directional_text: null,
    unit_identifier: unit || null,
    city_name: city ? city.toUpperCase() : null,
    state_code: state,
    postal_code: postal ? String(postal) : null,
    plus_four_postal_code: null,
    country_code: null,
    county_name: countyName || null,
    latitude: null,
    longitude: null,
    route_number: null,
    township: null,
    range: null,
    section: null,
    block: null,
    lot: null,
    municipality_name: null,
  };
}

function buildUtility(utilitiesJson, parcelId) {
  const key = `property_${parcelId}`;
  const src = utilitiesJson && utilitiesJson[key] ? utilitiesJson[key] : null;
  if (!src) return null;
  // Return as-is, ensuring required fields exist
  return {
    cooling_system_type: src.cooling_system_type ?? null,
    heating_system_type: src.heating_system_type ?? null,
    public_utility_type: src.public_utility_type ?? null,
    sewer_type: src.sewer_type ?? null,
    water_source_type: src.water_source_type ?? null,
    plumbing_system_type: src.plumbing_system_type ?? null,
    plumbing_system_type_other_description:
      src.plumbing_system_type_other_description ?? null,
    electrical_panel_capacity: src.electrical_panel_capacity ?? null,
    electrical_wiring_type: src.electrical_wiring_type ?? null,
    hvac_condensing_unit_present: src.hvac_condensing_unit_present ?? null,
    electrical_wiring_type_other_description:
      src.electrical_wiring_type_other_description ?? null,
    solar_panel_present: !!src.solar_panel_present,
    solar_panel_type: src.solar_panel_type ?? null,
    solar_panel_type_other_description:
      src.solar_panel_type_other_description ?? null,
    smart_home_features: src.smart_home_features ?? null,
    smart_home_features_other_description:
      src.smart_home_features_other_description ?? null,
    hvac_unit_condition: src.hvac_unit_condition ?? null,
    solar_inverter_visible: !!src.solar_inverter_visible,
    hvac_unit_issues: src.hvac_unit_issues ?? null,
  };
}

function buildLayouts(layoutsJson, parcelId) {
  const key = `property_${parcelId}`;
  const src = layoutsJson && layoutsJson[key] ? layoutsJson[key] : null;
  if (!src || !Array.isArray(src.layouts)) return [];
  return src.layouts.map((l) => ({
    space_type: l.space_type ?? null,
    space_index: l.space_index,
    flooring_material_type: l.flooring_material_type ?? null,
    size_square_feet: l.size_square_feet ?? null,
    floor_level: l.floor_level ?? null,
    has_windows: l.has_windows ?? null,
    window_design_type: l.window_design_type ?? null,
    window_material_type: l.window_material_type ?? null,
    window_treatment_type: l.window_treatment_type ?? null,
    is_finished: !!l.is_finished,
    furnished: l.furnished ?? null,
    paint_condition: l.paint_condition ?? null,
    flooring_wear: l.flooring_wear ?? null,
    clutter_level: l.clutter_level ?? null,
    visible_damage: l.visible_damage ?? null,
    countertop_material: l.countertop_material ?? null,
    cabinet_style: l.cabinet_style ?? null,
    fixture_finish_quality: l.fixture_finish_quality ?? null,
    design_style: l.design_style ?? null,
    natural_light_quality: l.natural_light_quality ?? null,
    decor_elements: l.decor_elements ?? null,
    pool_type: l.pool_type ?? null,
    pool_equipment: l.pool_equipment ?? null,
    spa_type: l.spa_type ?? null,
    safety_features: l.safety_features ?? null,
    view_type: l.view_type ?? null,
    lighting_features: l.lighting_features ?? null,
    condition_issues: l.condition_issues ?? null,
    is_exterior: !!l.is_exterior,
    pool_condition: l.pool_condition ?? null,
    pool_surface_type: l.pool_surface_type ?? null,
    pool_water_quality: l.pool_water_quality ?? null,
  }));
}

function buildStructure(parcel) {
  // Build structure with nulls where data isn't present, using allowed nulls for required fields
  const finished_base_area = parcel.bldgUnderAirFootage
    ? Number(String(parcel.bldgUnderAirFootage).replace(/[^0-9.]/g, ""))
    : null;
  return {
    architectural_style_type: null,
    attachment_type: null,
    exterior_wall_material_primary: null,
    exterior_wall_material_secondary: null,
    exterior_wall_condition: null,
    exterior_wall_insulation_type: null,
    flooring_material_primary: null,
    flooring_material_secondary: null,
    subfloor_material: null,
    flooring_condition: null,
    interior_wall_structure_material: null,
    interior_wall_surface_material_primary: null,
    interior_wall_surface_material_secondary: null,
    interior_wall_finish_primary: null,
    interior_wall_finish_secondary: null,
    interior_wall_condition: null,
    roof_covering_material: null,
    roof_underlayment_type: null,
    roof_structure_material: null,
    roof_design_type: null,
    roof_condition: null,
    roof_age_years: null,
    gutters_material: null,
    gutters_condition: null,
    roof_material_type: null,
    foundation_type: null,
    foundation_material: null,
    foundation_waterproofing: null,
    foundation_condition: null,
    ceiling_structure_material: null,
    ceiling_surface_material: null,
    ceiling_insulation_type: null,
    ceiling_height_average: null,
    ceiling_condition: null,
    exterior_door_material: null,
    interior_door_material: null,
    window_frame_material: null,
    window_glazing_type: null,
    window_operation_type: null,
    window_screen_material: null,
    primary_framing_material: null,
    secondary_framing_material: null,
    structural_damage_indicators: null,
    number_of_stories: null,
    finished_base_area: Number.isFinite(finished_base_area)
      ? finished_base_area
      : null,
    finished_upper_story_area: null,
    finished_basement_area: null,
    unfinished_base_area: null,
    unfinished_upper_story_area: null,
    unfinished_basement_area: null,
    exterior_wall_condition_primary: null,
    exterior_wall_condition_secondary: null,
    exterior_wall_insulation_type_primary: null,
    exterior_wall_insulation_type_secondary: null,
  };
}

function buildTax(parcel, seed) {
  const taxYear =
    seed &&
    seed.source_http_request &&
    seed.source_http_request.json &&
    seed.source_http_request.json.taxyear
      ? Number(seed.source_http_request.json.taxyear)
      : null;
  const assessed = parseCurrency(parcel.sohValue);
  const market = parseCurrency(parcel.justValue);
  const building = parseCurrency(parcel.bldgValue);
  const land = parseCurrency(parcel.landValue);
  const taxable = parseCurrency(parcel.taxableAmountCounty);
  if (
    taxYear == null ||
    assessed == null ||
    market == null ||
    building == null ||
    land == null ||
    taxable == null
  ) {
    return null;
  }
  return {
    tax_year: taxYear,
    property_assessed_value_amount: assessed,
    property_market_value_amount: market,
    property_building_amount: building,
    property_land_amount: land,
    property_taxable_value_amount: taxable,
    monthly_tax_amount: null,
    period_start_date: null,
    period_end_date: null,
    first_year_on_tax_roll: null,
    first_year_building_on_tax_roll: null,
    yearly_tax_amount: null,
  };
}

function buildTaxHistoryFromParcel(parcel, d) {
  // Build an additional tax record for prior year if we can source values from parcel fields
  const prior = {};
  // Attempt to get 2024 values from "LastYear" fields
  prior.tax_year = 2024;
  prior.property_assessed_value_amount = parseCurrency(parcel.sohLastYearValue);
  prior.property_market_value_amount = parseCurrency(parcel.justLastYearValue);
  prior.property_building_amount = parseCurrency(parcel.bldgLastYearValue);
  prior.property_land_amount = parseCurrency(parcel.landLastYearValue);
  // If taxable not directly available, align with assessed when exemptions appear to be zero (as evidenced by current year equality)
  const taxableLY = parseCurrency(parcel.taxableAmountCountyLastYear); // not present typically
  prior.property_taxable_value_amount =
    taxableLY != null
      ? taxableLY
      : prior.property_assessed_value_amount != null
        ? prior.property_assessed_value_amount
        : null;

  if (
    prior.property_assessed_value_amount == null ||
    prior.property_market_value_amount == null ||
    prior.property_taxable_value_amount == null
  ) {
    return null; // cannot construct schema-required fields
  }

  prior.monthly_tax_amount = null;
  prior.period_start_date = null;
  prior.period_end_date = null;
  prior.first_year_on_tax_roll = null;
  prior.first_year_building_on_tax_roll = null;
  prior.yearly_tax_amount = null;
  return prior;
}

function buildSales(parcel) {
  const outs = [];
  const pairs = [
    { date: parcel.saleDate1, price: parcel.stampAmount1 },
    { date: parcel.saleDate2, price: parcel.stampAmount2 },
    { date: parcel.saleDate3, price: parcel.stampAmount3 },
    { date: parcel.saleDate4, price: parcel.stampAmount4 },
    { date: parcel.saleDate5, price: parcel.stampAmount5 },
  ];
  for (const p of pairs) {
    const d = toISO(p.date);
    const amt = parseCurrency(p.price);
    if (d && amt != null) {
      outs.push({ ownership_transfer_date: d, purchase_price_amount: amt });
    }
  }
  return outs;
}

function buildDeeds(parcel) {
  const deeds = [];
  const ds = [
    parcel.deedType1,
    parcel.deedType2,
    parcel.deedType3,
    parcel.deedType4,
    parcel.deedType5,
  ];
  for (const dt of ds) {
    if (dt && typeof dt === "string" && dt.trim()) {
      deeds.push({ deed_type: dt.trim() });
    }
  }
  return deeds;
}

function buildPersons(ownerJson, parcelId) {
  const key = `property_${parcelId}`;
  const src = ownerJson && ownerJson[key] ? ownerJson[key] : null;
  if (!src || !src.owners_by_date) return { persons: [], byDateMap: {} };
  const byDateMap = src.owners_by_date;
  // Prefer a dated entry that appears to correspond to a sale event (e.g., 2009-07-20)
  const personsArr = [];
  const normalizePerson = (rec) => ({
    birth_date: null,
    first_name: titleCaseName(rec.first_name || ""),
    last_name: titleCaseName(rec.last_name || ""),
    middle_name: rec.middle_name ? titleCaseName(rec.middle_name) : null,
    prefix_name: null,
    suffix_name: null,
    us_citizenship_status: null,
    veteran_status: null,
  });
  // Collect unique current owners as default output
  const current = Array.isArray(byDateMap.current) ? byDateMap.current : [];
  for (const rec of current) {
    if (rec && rec.type === "person") personsArr.push(normalizePerson(rec));
  }
  return { persons: personsArr, byDateMap };
}

function deriveFileFormatFromUrl(url) {
  if (!url || typeof url !== "string") return null;
  const ext = path.extname(url.split("?")[0]).toLowerCase().replace(".", "");
  if (ext === "jpg" || ext === "jpeg") return "jpeg";
  if (ext === "png") return "png";
  if (ext === "txt") return "txt";
  return null;
}

function buildFiles(d) {
  const urls = new Set();
  if (
    d &&
    d.picturesListk__BackingField &&
    Array.isArray(d.picturesListk__BackingField)
  ) {
    d.picturesListk__BackingField.forEach((u) => {
      if (u) urls.add(u);
    });
  }
  if (
    d &&
    d.parcelInfok__BackingField &&
    Array.isArray(d.parcelInfok__BackingField) &&
    d.parcelInfok__BackingField[0] &&
    d.parcelInfok__BackingField[0].picturePath
  ) {
    urls.add(d.parcelInfok__BackingField[0].picturePath);
  }
  const out = [];
  Array.from(urls).forEach((u) => {
    const name = path.basename(u.split("?")[0]);
    const file_format = deriveFileFormatFromUrl(u);
    out.push({
      file_format,
      name,
      original_url: encodeURI(u),
      ipfs_url: null,
      document_type: "PropertyImage",
    });
  });
  return out;
}

function main() {
  ensureDir("data");

  const input = readJson("input.json");
  const unAddr = readJson("unnormalized_address.json");
  const seed = readJson("property_seed.json");

  const { d, parcel } = extractFromInput(input);
  const parcelId =
    parcel && parcel.folioNumber
      ? parcel.folioNumber
      : (seed && seed.parcel_id) || (seed && seed.request_identifier) || null;

  // Property
  if (parcel && parcel.folioNumber) {
    const prop = buildProperty(parcel);
    writeJson(path.join("data", "property.json"), prop);
  }

  // Address
  if (parcel) {
    const addr = buildAddress(parcel, unAddr);
    writeJson(path.join("data", "address.json"), addr);
  }

  // Utility (from owners/utilities_data.json)
  let utilitiesJson = null;
  try {
    utilitiesJson = readJson(path.join("owners", "utilities_data.json"));
  } catch (e) {}
  if (parcelId && utilitiesJson) {
    const util = buildUtility(utilitiesJson, parcelId);
    if (util) writeJson(path.join("data", "utility.json"), util);
  }

  // Layouts (from owners/layout_data.json)
  let layoutsJson = null;
  try {
    layoutsJson = readJson(path.join("owners", "layout_data.json"));
  } catch (e) {}
  if (parcelId && layoutsJson) {
    const layouts = buildLayouts(layoutsJson, parcelId);
    layouts.forEach((l, idx) => {
      writeJson(path.join("data", `layout_${idx + 1}.json`), l);
    });
  }

  // Structure (from input only)
  if (parcel) {
    const structure = buildStructure(parcel);
    writeJson(path.join("data", "structure.json"), structure);
  }

  // Tax current year
  const tax = buildTax(parcel, seed);
  const taxFiles = [];
  if (tax) {
    writeJson(path.join("data", "tax_1.json"), tax);
    taxFiles.push("tax_1.json");
  }
  // Tax prior year (2024) based on available "LastYear" fields if possible
  const taxPrior = buildTaxHistoryFromParcel(parcel, d);
  if (taxPrior) {
    writeJson(path.join("data", "tax_2.json"), taxPrior);
    taxFiles.push("tax_2.json");
  }

  // Sales
  const sales = buildSales(parcel);
  const salesFiles = [];
  sales.forEach((s, idx) => {
    const fname = `sales_${idx + 1}.json`;
    salesFiles.push(fname);
    writeJson(path.join("data", fname), s);
  });

  // Deeds
  const deeds = buildDeeds(parcel);
  const deedFiles = [];
  deeds.forEach((dobj, idx) => {
    const fname = `deed_${idx + 1}.json`;
    deedFiles.push(fname);
    writeJson(path.join("data", fname), dobj);
  });

  // Files (Property images)
  const files = buildFiles(d);
  const fileFiles = [];
  files.forEach((fobj, idx) => {
    const fname = `file_${idx + 1}.json`;
    fileFiles.push(fname);
    writeJson(path.join("data", fname), fobj);
  });

  // Owners (persons only per provided data)
  let ownersJson = null;
  try {
    ownersJson = readJson(path.join("owners", "owner_data.json"));
  } catch (e) {}
  const personFiles = [];
  let ownersByDate = {};
  if (ownersJson && parcelId) {
    const { persons, byDateMap } = buildPersons(ownersJson, parcelId);
    ownersByDate = byDateMap || {};
    persons.forEach((p, idx) => {
      const fname = `person_${idx + 1}.json`;
      personFiles.push(fname);
      writeJson(path.join("data", fname), p);
    });
  }

  // Relationships: sales -> persons for matching purchase date
  // Choose the sale date that matches an owners_by_date key if possible
  let relSalesPerson = [];
  if (salesFiles.length > 0 && personFiles.length > 0) {
    // Try to find a sale index that matches a date key
    let matchIdx = 0; // default to first sale
    const dateKeys = Object.keys(ownersByDate || {}).filter((k) =>
      /^\d{4}-\d{2}-\d{2}$/.test(k),
    );
    if (dateKeys.length > 0) {
      const keyIso = dateKeys[0];
      // Find sales with same date
      for (let i = 0; i < sales.length; i++) {
        if (sales[i].ownership_transfer_date === keyIso) {
          matchIdx = i;
          break;
        }
      }
    }
    // Link each person to the selected sale file
    for (let i = 0; i < personFiles.length; i++) {
      relSalesPerson.push({
        to: { "/": `./${personFiles[i]}` },
        from: { "/": `./${salesFiles[matchIdx]}` },
      });
    }
  }
  if (relSalesPerson.length > 0) {
    writeJson(
      path.join("data", "relationship_sales_person.json"),
      relSalesPerson,
    );
  }

  // Relationships: sales -> deeds (align by index order)
  const relSalesDeed = [];
  const n = Math.min(salesFiles.length, deedFiles.length);
  for (let i = 0; i < n; i++) {
    relSalesDeed.push({
      to: { "/": `./${salesFiles[i]}` },
      from: { "/": `./${deedFiles[i]}` },
    });
  }
  if (relSalesDeed.length > 0) {
    writeJson(path.join("data", "relationship_sales_deed.json"), relSalesDeed);
  }

  // Relationship: deed -> file (link first deed to each file for reference)
  if (deedFiles.length > 0 && fileFiles.length > 0) {
    const relDeedFile = fileFiles.map((ff) => ({
      to: { "/": `./${deedFiles[0]}` },
      from: { "/": `./${ff}` },
    }));
    writeJson(path.join("data", "relationship_deed_file.json"), relDeedFile);
  }
}

if (require.main === module) {
  try {
    main();
    console.log("Extraction complete.");
  } catch (e) {
    console.error("Extraction failed:", e);
    process.exit(1);
  }
}
